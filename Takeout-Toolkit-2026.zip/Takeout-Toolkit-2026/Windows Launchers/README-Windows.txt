Run 00_SETUP_WINDOWS.bat once.

Then run the pipeline for each data source (01/03/05/07).
After that, open the viewers (02/04/06/08).

Tip: you can drag-and-drop the source file onto the pipeline .bat files.
