from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import streamlit as st

APP_TITLE = "📁 InboxGPT (Fast Batch Labeling)"
DEFAULT_DB = "inboxgpt.sqlite"


# -----------------------------
# DB helpers
# -----------------------------
def _db_path() -> Path:
    # Keep DB in the working directory by default; user can move it later.
    p = st.session_state.get("db_path") or DEFAULT_DB
    return Path(p)


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(_db_path(), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA synchronous=NORMAL;")
    return conn


def init_db() -> None:
    conn = get_conn()
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS chats (
            id TEXT PRIMARY KEY,
            title TEXT,
            created_at TEXT,
            updated_at TEXT,
            model TEXT,
            -- content_snip is used for search; we store a truncated string for speed
            content_snip TEXT
        );

        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL
        );

        CREATE TABLE IF NOT EXISTS chat_categories (
            chat_id TEXT NOT NULL,
            category_id INTEGER NOT NULL,
            PRIMARY KEY (chat_id, category_id),
            FOREIGN KEY (chat_id) REFERENCES chats(id) ON DELETE CASCADE,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_chats_created_at ON chats(created_at);
        CREATE INDEX IF NOT EXISTS idx_chats_title ON chats(title);
        CREATE INDEX IF NOT EXISTS idx_chat_categories_chat ON chat_categories(chat_id);
        CREATE INDEX IF NOT EXISTS idx_chat_categories_cat ON chat_categories(category_id);
        """
    )
    conn.commit()
    conn.close()


def upsert_chat(row: Dict[str, Any]) -> None:
    conn = get_conn()
    conn.execute(
        """
        INSERT INTO chats (id, title, created_at, updated_at, model, content_snip)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          title=excluded.title,
          created_at=COALESCE(excluded.created_at, chats.created_at),
          updated_at=COALESCE(excluded.updated_at, chats.updated_at),
          model=COALESCE(excluded.model, chats.model),
          content_snip=COALESCE(excluded.content_snip, chats.content_snip)
        """,
        (
            row["id"],
            row.get("title"),
            row.get("created_at"),
            row.get("updated_at"),
            row.get("model"),
            row.get("content_snip"),
        ),
    )
    conn.commit()
    conn.close()


def upsert_chats_bulk(rows: List[Dict[str, Any]]) -> None:
    if not rows:
        return
    conn = get_conn()
    conn.executemany(
        """
        INSERT INTO chats (id, title, created_at, updated_at, model, content_snip)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
          title=excluded.title,
          created_at=COALESCE(excluded.created_at, chats.created_at),
          updated_at=COALESCE(excluded.updated_at, chats.updated_at),
          model=COALESCE(excluded.model, chats.model),
          content_snip=COALESCE(excluded.content_snip, chats.content_snip)
        """,
        [
            (
                r["id"],
                r.get("title"),
                r.get("created_at"),
                r.get("updated_at"),
                r.get("model"),
                r.get("content_snip"),
            )
            for r in rows
        ],
    )
    conn.commit()
    conn.close()


def list_categories() -> List[Dict[str, Any]]:
    conn = get_conn()
    rows = conn.execute(
        """
        SELECT categories.id, categories.name,
               (SELECT COUNT(*) FROM chat_categories WHERE category_id = categories.id) AS n
        FROM categories
        ORDER BY LOWER(categories.name) ASC
        """
    ).fetchall()
    conn.close()
    return [{"id": r["id"], "name": r["name"], "count": r["n"]} for r in rows]


def _ensure_categories(names: List[str]) -> List[int]:
    """Create categories if needed; return their ids in the same order as names."""
    cleaned = [n.strip() for n in names if n and n.strip()]
    if not cleaned:
        return []
    conn = get_conn()
    for n in cleaned:
        conn.execute("INSERT OR IGNORE INTO categories (name) VALUES (?)", (n,))
    conn.commit()
    rows = conn.execute(
        f"SELECT id, name FROM categories WHERE name IN ({','.join(['?']*len(cleaned))})",
        cleaned,
    ).fetchall()
    conn.close()
    name_to_id = {r["name"]: r["id"] for r in rows}
    return [name_to_id[n] for n in cleaned if n in name_to_id]


def assign_categories(chat_ids: List[str], category_names: List[str]) -> int:
    cat_ids = _ensure_categories(category_names)
    if not chat_ids or not cat_ids:
        return 0
    conn = get_conn()
    conn.executemany(
        "INSERT OR IGNORE INTO chat_categories (chat_id, category_id) VALUES (?, ?)",
        [(cid, cat_id) for cid in chat_ids for cat_id in cat_ids],
    )
    n = conn.total_changes
    conn.commit()
    conn.close()
    return int(n)


def remove_categories(chat_ids: List[str], category_names: List[str]) -> int:
    if not chat_ids or not category_names:
        return 0
    conn = get_conn()
    rows = conn.execute(
        f"SELECT id, name FROM categories WHERE name IN ({','.join(['?']*len(category_names))})",
        [n.strip() for n in category_names if n.strip()],
    ).fetchall()
    cat_ids = [r["id"] for r in rows]
    if not cat_ids:
        conn.close()
        return 0
    conn.executemany(
        f"DELETE FROM chat_categories WHERE chat_id=? AND category_id=?",
        [(cid, cat_id) for cid in chat_ids for cat_id in cat_ids],
    )
    n = conn.total_changes
    conn.commit()
    conn.close()
    return int(n)


def count_chats(search: str = "", category_ids: Optional[List[int]] = None) -> int:
    conn = get_conn()
    q = "SELECT COUNT(DISTINCT c.id) FROM chats c "
    params: List[Any] = []
    where: List[str] = []

    if category_ids:
        placeholders = ",".join(["?"] * len(category_ids))
        q += f"""
            JOIN (
                SELECT chat_id
                FROM chat_categories
                WHERE category_id IN ({placeholders})
                GROUP BY chat_id
                HAVING COUNT(DISTINCT category_id) = {len(category_ids)}
            ) must ON must.chat_id = c.id
        """
        params.extend(category_ids)

    if search:
        where.append("(LOWER(c.title) LIKE ? OR LOWER(c.content_snip) LIKE ?)")
        s = f"%{search.lower()}%"
        params.extend([s, s])

    if where:
        q += " WHERE " + " AND ".join(where)

    n = conn.execute(q, params).fetchone()[0]
    conn.close()
    return int(n or 0)


def list_chats_page(
    search: str = "",
    category_ids: Optional[List[int]] = None,
    sort: str = "newest",
    limit: int = 50,
    offset: int = 0,
) -> List[Dict[str, Any]]:
    conn = get_conn()
    q = """
        SELECT c.id, c.title, c.created_at, c.updated_at, c.model,
               COALESCE(GROUP_CONCAT(cat.name, ', '), '') AS categories
        FROM chats c
        LEFT JOIN chat_categories cc ON c.id = cc.chat_id
        LEFT JOIN categories cat ON cc.category_id = cat.id
    """
    params: List[Any] = []
    where: List[str] = []

    if category_ids:
        placeholders = ",".join(["?"] * len(category_ids))
        q += f"""
            JOIN (
                SELECT chat_id
                FROM chat_categories
                WHERE category_id IN ({placeholders})
                GROUP BY chat_id
                HAVING COUNT(DISTINCT category_id) = {len(category_ids)}
            ) must ON must.chat_id = c.id
        """
        params.extend(category_ids)

    if search:
        where.append("(LOWER(c.title) LIKE ? OR LOWER(c.content_snip) LIKE ?)")
        s = f"%{search.lower()}%"
        params.extend([s, s])

    if where:
        q += " WHERE " + " AND ".join(where)

    q += " GROUP BY c.id "

    if sort == "newest":
        q += " ORDER BY datetime(c.created_at) DESC, c.title COLLATE NOCASE ASC"
    elif sort == "oldest":
        q += " ORDER BY datetime(c.created_at) ASC, c.title COLLATE NOCASE ASC"
    else:
        q += " ORDER BY c.title COLLATE NOCASE ASC"

    q += " LIMIT ? OFFSET ?"
    params.extend([int(limit), int(offset)])

    rows = conn.execute(q, params).fetchall()
    conn.close()
    return [
        {
            "id": r["id"],
            "title": r["title"],
            "created_at": r["created_at"],
            "updated_at": r["updated_at"],
            "model": r["model"],
            "categories": r["categories"],
        }
        for r in rows
    ]


# -----------------------------
# Import helpers (ChatGPT export)
# -----------------------------
def _iso_from_epoch(ts: Any) -> Optional[str]:
    if ts is None:
        return None
    try:
        # Some exports use seconds (float), some ms
        t = float(ts)
        if t > 10_000_000_000:  # ms
            t = t / 1000.0
        return datetime.utcfromtimestamp(t).isoformat(timespec="seconds") + "Z"
    except Exception:
        return None


def _extract_text_snip(conv_obj: Dict[str, Any], max_chars: int = 4000) -> str:
    """
    Pull a small amount of text from the conversation for searchability.
    We avoid storing the full message tree in DB for speed.
    """
    parts: List[str] = []

    mapping = conv_obj.get("mapping") or {}
    if isinstance(mapping, dict):
        # Iterate nodes; try to collect user + assistant message text
        for node in mapping.values():
            msg = (node or {}).get("message") or {}
            content = (msg or {}).get("content") or {}
            ctype = content.get("content_type")
            if ctype == "text":
                txt = content.get("parts") or []
                if isinstance(txt, list):
                    for p in txt:
                        if isinstance(p, str) and p.strip():
                            parts.append(p.strip())
            # Older exports sometimes have "text" directly
            if isinstance(content, str) and content.strip():
                parts.append(content.strip())

            if sum(len(p) for p in parts) >= max_chars:
                break

    snip = "\n".join(parts)
    return snip[:max_chars]


def normalize_conversations_json(raw: Any) -> List[Dict[str, Any]]:
    """
    Accepts ChatGPT export JSON in a few shapes:
      - A list of conversation objects
      - A dict with 'conversations' or similar
    Returns a list of rows for DB upsert.
    """
    if isinstance(raw, dict):
        if "conversations" in raw and isinstance(raw["conversations"], list):
            convs = raw["conversations"]
        elif "data" in raw and isinstance(raw["data"], list):
            convs = raw["data"]
        else:
            # Sometimes the export is a dict keyed by id
            convs = list(raw.values()) if all(isinstance(v, dict) for v in raw.values()) else []
    elif isinstance(raw, list):
        convs = raw
    else:
        convs = []

    rows: List[Dict[str, Any]] = []
    for c in convs:
        if not isinstance(c, dict):
            continue
        cid = c.get("id") or c.get("conversation_id")
        if not cid:
            continue
        title = c.get("title") or ""
        created = _iso_from_epoch(c.get("create_time") or c.get("created_at"))
        updated = _iso_from_epoch(c.get("update_time") or c.get("updated_at"))
        model = c.get("model") or c.get("default_model_slug") or ""
        content_snip = _extract_text_snip(c, max_chars=4000)
        rows.append(
            {
                "id": str(cid),
                "title": str(title) if title is not None else "",
                "created_at": created,
                "updated_at": updated,
                "model": str(model) if model is not None else "",
                "content_snip": content_snip,
            }
        )
    return rows


def import_conversations(file_bytes: bytes) -> Tuple[int, int]:
    """
    Returns (imported_count, total_found)
    """
    raw = json.loads(file_bytes.decode("utf-8"))
    rows = normalize_conversations_json(raw)
    total = len(rows)
    if not total:
        return (0, 0)

    # Bulk insert in chunks
    imported = 0
    CHUNK = 500
    for i in range(0, total, CHUNK):
        chunk = rows[i : i + CHUNK]
        upsert_chats_bulk(chunk)
        imported += len(chunk)

    return (imported, total)


# -----------------------------
# UI
# -----------------------------
def tag_badge(label: str) -> None:
    st.markdown(
        f"""
        <span style="
          display:inline-block;
          padding:2px 8px;
          margin:2px 4px 2px 0;
          border:1px solid rgba(255,255,255,0.25);
          border-radius:999px;
          font-size:12px;
          opacity:0.95;
        ">{label}</span>
        """,
        unsafe_allow_html=True,
    )


def main() -> None:
    st.set_page_config(page_title="InboxGPT", layout="wide")
    st.title(APP_TITLE)
    st.caption("Local-only. Designed to stay fast even when your conversations.json is large.")

    init_db()

    # Session state for selection
    if "selected_ids" not in st.session_state:
        st.session_state.selected_ids = set()

    with st.sidebar:
        st.subheader("Import / Export")
        st.text_input("DB file path", value=str(_db_path()), key="db_path", help="You can change this if you want the SQLite DB somewhere else.")
        up = st.file_uploader("ChatGPT export conversations.json", type=["json"])
        if up is not None:
            if st.button("Import into local DB", use_container_width=True):
                with st.spinner("Importing (first time can take a bit)…"):
                    imported, total = import_conversations(up.getvalue())
                if total == 0:
                    st.error("Couldn't find conversations in that JSON file.")
                else:
                    st.success(f"Imported/updated {imported} conversations.")
                    st.session_state.selected_ids = set()
                    st.rerun()

        st.divider()
        st.subheader("List filters")
        search = st.text_input("Search title / snippet", value="", placeholder="type to filter…")
        cats = list_categories()
        cat_name_to_id = {c["name"]: c["id"] for c in cats}
        cat_filter_names = st.multiselect("Filter by categories (must include all)", options=list(cat_name_to_id.keys()))
        cat_filter_ids = [cat_name_to_id[n] for n in cat_filter_names if n in cat_name_to_id]
        sort = st.selectbox("Sort", ["newest", "oldest", "title"])

        st.divider()
        st.subheader("Selection tools")
        if st.button("Clear selection", use_container_width=True):
            st.session_state.selected_ids = set()
            st.rerun()

    # Pagination settings (main area)
    top = st.columns([0.2, 0.8])
    with top[0]:
        page_size = st.selectbox("Rows per page", [25, 50, 100, 200], index=1)
    with top[1]:
        st.write("")

    total = count_chats(search=search, category_ids=cat_filter_ids)
    if "page" not in st.session_state:
        st.session_state.page = 0
    max_page = max(0, (total - 1) // page_size)
    st.session_state.page = min(st.session_state.page, max_page)

    nav1, nav2, nav3, nav4 = st.columns([0.15, 0.25, 0.20, 0.40])
    with nav1:
        if st.button("⟵ Prev", disabled=(st.session_state.page <= 0)):
            st.session_state.page -= 1
            st.rerun()
    with nav2:
        st.write(f"Page {st.session_state.page + 1} / {max_page + 1}")
    with nav3:
        st.write(f"Total: {total}")
    with nav4:
        if st.button("Next ⟶", disabled=(st.session_state.page >= max_page)):
            st.session_state.page += 1
            st.rerun()

    offset = st.session_state.page * page_size
    chats = list_chats_page(
        search=search,
        category_ids=cat_filter_ids,
        sort=sort,
        limit=page_size,
        offset=offset,
    )

    st.markdown("---")
    st.subheader("Conversations (no per-row preview)")

    # Page selection helpers
    s1, s2, s3, s4 = st.columns([0.2, 0.2, 0.2, 0.4])
    with s1:
        if st.button("Select page", use_container_width=True, disabled=(len(chats) == 0)):
            for c in chats:
                st.session_state.selected_ids.add(c["id"])
            st.rerun()
    with s2:
        if st.button("Unselect page", use_container_width=True, disabled=(len(chats) == 0)):
            for c in chats:
                st.session_state.selected_ids.discard(c["id"])
            st.rerun()
    with s3:
        st.write(f"Selected: {len(st.session_state.selected_ids)}")
    with s4:
        st.write("")

    # List header
    h = st.columns([0.06, 0.62, 0.32])
    h[0].markdown("**✓**")
    h[1].markdown("**Title / Date**")
    h[2].markdown("**Categories**")

    for i, chat in enumerate(chats):
        cols = st.columns([0.06, 0.62, 0.32])
        key = f"sel_{chat['id']}"
        currently = chat["id"] in st.session_state.selected_ids
        with cols[0]:
            checked = st.checkbox("", value=currently, key=key)
        with cols[1]:
            title = chat["title"] or "(untitled)"
            st.markdown(f"**{title}**")
            if chat.get("created_at"):
                st.caption(chat["created_at"])
        with cols[2]:
            cats_here = [c.strip() for c in (chat.get("categories") or "").split(",") if c.strip()]
            if cats_here:
                for c in cats_here:
                    tag_badge(c)
            else:
                st.caption("—")

        if checked:
            st.session_state.selected_ids.add(chat["id"])
        else:
            st.session_state.selected_ids.discard(chat["id"])

    st.markdown("---")
    st.subheader("Batch labeling")

    cats = list_categories()
    existing_names = [c["name"] for c in cats]

    left, right = st.columns([0.6, 0.4])
    with left:
        add_existing = st.multiselect("Add existing categories", options=existing_names)
        add_new = st.text_input("Add new categories (comma-separated)", value="", placeholder="e.g. philosophy, coding, health")
        add_names = add_existing + [n.strip() for n in add_new.split(",") if n.strip()]

        if st.button("Apply add → selected chats", type="primary", disabled=(len(st.session_state.selected_ids) == 0 or len(add_names) == 0)):
            n = assign_categories(sorted(st.session_state.selected_ids), add_names)
            st.success(f"Added labels to selected chats. (DB changes: {n})")
            st.rerun()

    with right:
        remove_names = st.multiselect("Remove categories from selected", options=existing_names)
        if st.button("Apply remove → selected chats", disabled=(len(st.session_state.selected_ids) == 0 or len(remove_names) == 0)):
            n = remove_categories(sorted(st.session_state.selected_ids), remove_names)
            st.warning(f"Removed labels from selected chats. (DB changes: {n})")
            st.rerun()

    st.markdown("---")
    st.subheader("Category summary")
    cats = list_categories()
    if not cats:
        st.caption("No categories yet.")
    else:
        cols = st.columns(4)
        for i, c in enumerate(cats):
            with cols[i % 4]:
                st.metric(c["name"], int(c["count"]))


if __name__ == "__main__":
    main()
