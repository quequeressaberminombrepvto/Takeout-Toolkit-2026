#!/usr/bin/env python3
from __future__ import annotations

import re
from pathlib import Path
from datetime import datetime
import pandas as pd
import streamlit as st


# -------------------------
# Helpers
# -------------------------
def find_runs(pipeline_root: Path) -> list[Path]:
    if not pipeline_root.exists():
        return []
    runs = [p for p in pipeline_root.iterdir() if p.is_dir() and p.name.startswith("run_")]
    # sort by folder name (YYYYMMDD_HHMMSS) descending
    runs.sort(key=lambda p: p.name, reverse=True)
    return runs


def read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        return f"(Could not read {path.name}: {e})"


def safe_read_csv(path: Path) -> pd.DataFrame:
    try:
        return pd.read_csv(path)
    except Exception as e:
        st.error(f"Failed to read CSV: {path}\n\n{e}")
        return pd.DataFrame()


def human_dt_from_runname(name: str) -> str:
    # run_20260103_170304
    m = re.match(r"run_(\d{8})_(\d{6})", name)
    if not m:
        return name
    ymd, hms = m.group(1), m.group(2)
    dt = datetime.strptime(ymd + hms, "%Y%m%d%H%M%S")
    return dt.strftime("%b %d, %Y %I:%M:%S %p")


def latest_run(pipeline_root: Path) -> Path | None:
    runs = find_runs(pipeline_root)
    return runs[0] if runs else None


# -------------------------
# App
# -------------------------
st.set_page_config(page_title="ChatGPT Pipeline Explorer", layout="wide")
st.title("🧭 ChatGPT Pipeline Explorer")
st.caption("Explore Theme Miner + Analyzer outputs from your pipeline runs (local-only).")

# Assume this file sits next to pipeline_out/
HERE = Path(__file__).resolve().parent
PIPELINE_ROOT = HERE / "pipeline_out"

runs = find_runs(PIPELINE_ROOT)
if not runs:
    st.error(
        f"Couldn't find any runs under: {PIPELINE_ROOT}\n\n"
        "Put this app in the same folder that contains the `pipeline_out` directory."
    )
    st.stop()

# Run selector
run_labels = {r.name: f"{r.name} — {human_dt_from_runname(r.name)}" for r in runs}
default_run = runs[0].name
selected_run_name = st.sidebar.selectbox(
    "Select a run", options=[r.name for r in runs], index=0, format_func=lambda k: run_labels.get(k, k)
)
RUN_DIR = PIPELINE_ROOT / selected_run_name

THEME_DIR = RUN_DIR / "theme_miner"
ANALYZE_DIR = RUN_DIR / "analyze_export"

st.sidebar.markdown("---")
st.sidebar.write("**Detected folders:**")
st.sidebar.code(str(RUN_DIR), language="text")

# Load files (if present)
theme_labeled = safe_read_csv(THEME_DIR / "conversations_labeled.csv")
theme_terms = safe_read_csv(THEME_DIR / "clusters_top_terms.csv")
themes_summary_md = read_text(THEME_DIR / "themes_summary.md")

cluster_summary = safe_read_csv(ANALYZE_DIR / "cluster_summary.csv")
clusters = safe_read_csv(ANALYZE_DIR / "clusters.csv")
flat = safe_read_csv(ANALYZE_DIR / "conversations_flat.csv")
msgs = safe_read_csv(ANALYZE_DIR / "conversations_messages_sample.csv")

# Main layout
tab1, tab2, tab3, tab4 = st.tabs(["🧩 Themes", "🧪 Clusters (Analyzer)", "🔎 Conversations", "💬 Message Samples"])

# -------------------------
# Themes tab
# -------------------------
with tab1:
    left, right = st.columns([0.55, 0.45])

    with left:
        st.subheader("Themes summary (Markdown)")
        st.markdown(themes_summary_md if themes_summary_md.strip() else "_No themes_summary.md found._")

    with right:
        st.subheader("Theme overview")
        if theme_labeled.empty:
            st.info("No Theme Miner CSV found for this run.")
        else:
            # Theme Miner uses cluster_id/cluster_label naming in its CSV
            # (If your version differs, adapt column names here)
            cols = theme_labeled.columns.tolist()
            if "cluster_id" not in cols:
                st.warning(f"Unexpected columns in conversations_labeled.csv: {cols}")
            else:
                # Counts
                counts = (
                    theme_labeled.groupby(["cluster_id", "cluster_label"], dropna=False)
                    .size()
                    .reset_index(name="count")
                    .sort_values("count", ascending=False)
                )
                st.dataframe(counts, use_container_width=True, hide_index=True)

                # Theme picker
                theme_ids = counts["cluster_id"].tolist()
                pick = st.selectbox("Open a theme", theme_ids, format_func=lambda x: f"Theme {int(x):02d}")
                theme_file = THEME_DIR / f"theme_{int(pick):02d}.md"
                st.markdown("---")
                st.subheader(f"theme_{int(pick):02d}.md")
                st.markdown(read_text(theme_file))

# -------------------------
# Analyzer clusters tab
# -------------------------
with tab2:
    c1, c2 = st.columns([0.55, 0.45])

    with c1:
        st.subheader("Cluster summary")
        if cluster_summary.empty:
            st.info("No analyzer cluster_summary.csv found for this run.")
        else:
            st.dataframe(cluster_summary, use_container_width=True, hide_index=True)

    with c2:
        st.subheader("Jump to a cluster")
        if clusters.empty:
            st.info("No analyzer clusters.csv found for this run.")
        else:
            if "cluster_id" not in clusters.columns:
                st.warning(f"Unexpected clusters.csv columns: {clusters.columns.tolist()}")
            else:
                cluster_ids = sorted(clusters["cluster_id"].dropna().unique().tolist())
                cid = st.selectbox("Cluster", cluster_ids)
                subset = clusters[clusters["cluster_id"] == cid].copy()

                # Join titles & text from conversations_flat if available
                if not flat.empty and "conversation_id" in flat.columns:
                    subset = subset.merge(
                        flat[["conversation_id", "title", "create_time", "doc_len", "doc_text"]],
                        on="conversation_id",
                        how="left",
                    )

                st.write(f"Conversations in cluster **{cid}**: {len(subset)}")
                st.dataframe(
                    subset[["conversation_id", "title", "create_time", "doc_len"]]
                    if all(k in subset.columns for k in ["conversation_id", "title", "create_time", "doc_len"])
                    else subset,
                    use_container_width=True,
                    hide_index=True,
                )

                # Preview one conversation
                if "doc_text" in subset.columns and subset["doc_text"].notna().any():
                    pick_id = st.selectbox("Preview conversation", subset["conversation_id"].tolist())
                    row = subset[subset["conversation_id"] == pick_id].head(1)
                    st.markdown("---")
                    st.subheader(row["title"].iloc[0] if "title" in row.columns else pick_id)
                    st.caption(row["create_time"].iloc[0] if "create_time" in row.columns else "")
                    st.text_area("Text", row["doc_text"].iloc[0], height=300)

# -------------------------
# Conversations tab
# -------------------------
with tab3:
    st.subheader("Search conversations (Analyzer flat)")
    if flat.empty:
        st.info("No conversations_flat.csv found for this run.")
    else:
        # Basic filters
        q = st.text_input("Search text/title", value="", placeholder="type to search…")
        min_len = st.slider("Minimum doc length", 0, int(flat["doc_len"].max() if "doc_len" in flat.columns else 5000), 0)

        df = flat.copy()
        if "doc_len" in df.columns:
            df = df[df["doc_len"].fillna(0) >= min_len]

        if q.strip():
            qs = q.strip().lower()
            title_ok = df["title"].astype(str).str.lower().str.contains(qs, na=False) if "title" in df.columns else False
            text_ok = df["doc_text"].astype(str).str.lower().str.contains(qs, na=False) if "doc_text" in df.columns else False
            df = df[title_ok | text_ok]

        st.write(f"Matches: **{len(df)}**")
        show_cols = [c for c in ["conversation_id", "title", "create_time", "update_time", "doc_len"] if c in df.columns]
        st.dataframe(df[show_cols], use_container_width=True, hide_index=True)

        if "conversation_id" in df.columns and "doc_text" in df.columns and len(df):
            chosen = st.selectbox("Open conversation", df["conversation_id"].tolist())
            row = df[df["conversation_id"] == chosen].head(1)
            st.markdown("---")
            st.subheader(row["title"].iloc[0] if "title" in row.columns else chosen)
            st.caption(row["create_time"].iloc[0] if "create_time" in row.columns else "")
            st.text_area("Text", row["doc_text"].iloc[0], height=420)

# -------------------------
# Message sample tab
# -------------------------
with tab4:
    st.subheader("Message samples")
    if msgs.empty:
        st.info("No conversations_messages_sample.csv found for this run.")
    else:
        st.dataframe(msgs.head(500), use_container_width=True, hide_index=True)
        st.caption("This table is a sample (first 50 messages per conversation) for quick previews.")
