#!/usr/bin/env python3
"""
Theme Miner for ChatGPT conversations.json (offline)

Fixes vs older versions
-----------------------
- Handles ChatGPT exports where many mapping nodes have message=None
  (common: root node has no message).
- Iterates all mapping nodes safely and extracts text from multiple common shapes.
- Writes a small "themes_summary.md" even when nothing survives filtering
  (so you never get an empty output folder without an explanation).

What it does
------------
Given a ChatGPT export file named conversations.json, this script:
- extracts the text of each conversation (user-only by default)
- filters out very short conversations
- clusters conversations into themes using TF-IDF + KMeans
- auto-labels each theme using top TF-IDF terms
- writes:
    - conversations_labeled.csv (one row per conversation)
    - clusters_top_terms.csv (top terms per theme)
    - themes_summary.md (human-readable summary)
    - theme_XX.md (one file per theme listing conversation titles)

Usage
-----
Basic:
    python theme_miner.py conversations.json

Choose number of themes:
    python theme_miner.py conversations.json --k 12

Include assistant messages too:
    python theme_miner.py conversations.json --include-assistant

Lower the minimum conversation size if you're filtering too hard:
    python theme_miner.py conversations.json --min-chars 200

Output to a specific folder:
    python theme_miner.py conversations.json --outdir my_theme_output

Notes
-----
- Clustering is unsupervised: theme IDs are arbitrary.
- Results depend on k, min-chars, and the language/content of your archive.
- This script does not call any online services. It runs fully offline.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import re
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import TfidfVectorizer


DEFAULT_STOP_EXTRA = {
    # ChatGPT-export filler + common chat words
    "yeah",
    "yep",
    "okay",
    "ok",
    "lol",
    "uh",
    "um",
    "gonna",
    "wanna",
    "thing",
    "stuff",
    "like",
    "just",
    "really",
    "actually",
    "basically",
    "chatgpt",
    "assistant",
    "user",
}


# ----------------------------
# Text helpers
# ----------------------------


def clean_text(s: str) -> str:
    s = s.replace("\u0000", " ")
    s = re.sub(r"\s+", " ", s).strip()
    return s


def normalize_for_vectorizer(s: str) -> str:
    # Keep this fairly simple; TF-IDF works better with normalized tokens
    s = s.lower()
    s = re.sub(r"https?://\S+", " ", s)  # remove URLs
    s = re.sub(r"[^a-z0-9\s]", " ", s)  # keep words/numbers/spaces
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _iso_from_epoch(ts: Any) -> Optional[str]:
    if ts is None:
        return None
    try:
        t = float(ts)
        # exports are usually seconds; but if ms, convert
        if t > 10_000_000_000:
            t = t / 1000.0
        return datetime.fromtimestamp(t, tz=timezone.utc).isoformat(timespec="seconds")
    except Exception:
        return None


# ----------------------------
# ChatGPT export parsing
# ----------------------------


def iter_message_dicts(convo: Dict[str, Any]) -> Iterable[Dict[str, Any]]:
    """
    Yield message dicts from a conversation object.

    ChatGPT exports often look like:
      convo["mapping"] = { node_id: { "message": {...} or None, ... }, ... }

    Root nodes commonly have message=None; we skip those safely.
    """
    mapping = convo.get("mapping")
    if isinstance(mapping, dict):
        for node in mapping.values():
            if not isinstance(node, dict):
                continue
            msg = node.get("message")
            if isinstance(msg, dict):
                yield msg
        return

    # Fallback: some variants store messages directly
    msgs = convo.get("messages")
    if isinstance(msgs, list):
        for m in msgs:
            if isinstance(m, dict):
                yield m


def extract_text_from_message(msg: Dict[str, Any]) -> str:
    """
    Pull human-readable text from a message dict.

    Most common:
      msg["content"] = {"content_type":"text","parts":[...]}
    But exports can vary; handle some common fallbacks.
    """
    content = msg.get("content")

    if content is None:
        return ""

    # Typical dict shape
    if isinstance(content, dict):
        ctype = content.get("content_type")
        if ctype == "text":
            parts = content.get("parts")
            if isinstance(parts, list):
                out = []
                for p in parts:
                    if isinstance(p, str) and p.strip():
                        out.append(p.strip())
                return "\n".join(out).strip()

        # Fallbacks sometimes present
        for k in ("text", "result", "output", "message", "value"):
            v = content.get(k)
            if isinstance(v, str) and v.strip():
                return v.strip()

        return ""

    # Sometimes it's just a string
    if isinstance(content, str):
        return content.strip()

    # Sometimes list of strings
    if isinstance(content, list):
        out = []
        for x in content:
            if isinstance(x, str) and x.strip():
                out.append(x.strip())
        return "\n".join(out).strip()

    return ""


def extract_conversation_text(
    convo: Dict[str, Any],
    include_assistant: bool = False,
    include_system: bool = False,
    include_tool: bool = False,
) -> str:
    """
    Flatten a conversation into a single text document.
    By default: user-only.
    """
    parts: List[str] = []

    for msg in iter_message_dicts(convo):
        author = msg.get("author")
        role = ""
        if isinstance(author, dict):
            role = author.get("role") or ""
        elif isinstance(author, str):
            role = author

        if role == "system" and not include_system:
            continue
        if role in ("tool", "function") and not include_tool:
            continue
        if role == "assistant" and not include_assistant:
            continue
        if role not in ("user", "assistant", "system", "tool", "function"):
            # unknown roles: ignore
            continue

        txt = extract_text_from_message(msg)
        txt = clean_text(txt)
        if not txt:
            continue

        # Keep the role prefix for context (helps clustering)
        if role:
            parts.append(f"{role.upper()}: {txt}")
        else:
            parts.append(txt)

    return "\n".join(parts).strip()


def load_conversations(path: Path) -> List[Dict[str, Any]]:
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    # Most common: list of conversation objects
    if isinstance(data, list):
        return [x for x in data if isinstance(x, dict)]

    # Some variants: dict with "conversations" list
    if isinstance(data, dict):
        if isinstance(data.get("conversations"), list):
            return [x for x in data["conversations"] if isinstance(x, dict)]
        if isinstance(data.get("data"), list):
            return [x for x in data["data"] if isinstance(x, dict)]
        # dict keyed by ids
        vals = list(data.values())
        if vals and all(isinstance(v, dict) for v in vals):
            return vals

    return []


# ----------------------------
# Theme modeling
# ----------------------------


def choose_k(n: int, k: Optional[int]) -> int:
    if k is not None:
        return max(2, int(k))
    # heuristic for broad buckets
    if n < 50:
        return 6
    if n < 200:
        return 10
    if n < 800:
        return 18
    return 25


def top_terms_per_cluster(
    vectorizer: TfidfVectorizer, model: KMeans, top_n: int = 12
) -> Dict[int, List[str]]:
    terms = vectorizer.get_feature_names_out()
    centers = model.cluster_centers_
    out: Dict[int, List[str]] = {}
    for cid in range(centers.shape[0]):
        idx = centers[cid].argsort()[::-1][:top_n]
        out[cid] = [terms[i] for i in idx]
    return out


def label_from_terms(terms: List[str]) -> str:
    if not terms:
        return "Unlabeled"
    head = terms[:4]
    return " / ".join(head)


@dataclass
class ConvoDoc:
    convo_id: str
    title: str
    created_at: Optional[str]
    updated_at: Optional[str]
    doc_text: str
    doc_len: int


def build_docs(
    convos: List[Dict[str, Any]],
    include_assistant: bool,
    include_system: bool,
    include_tool: bool,
    min_chars: int,
) -> List[ConvoDoc]:
    docs: List[ConvoDoc] = []
    for c in convos:
        cid = (
            str(c.get("id") or c.get("conversation_id") or c.get("uuid") or "")
        ).strip()
        if not cid:
            # Not critical; skip weird entries
            continue

        title = str(c.get("title") or "").strip()
        created = _iso_from_epoch(c.get("create_time") or c.get("created_at"))
        updated = _iso_from_epoch(c.get("update_time") or c.get("updated_at"))

        text = extract_conversation_text(
            c,
            include_assistant=include_assistant,
            include_system=include_system,
            include_tool=include_tool,
        )
        if not text:
            continue

        # Filter tiny conversations
        if len(text) < int(min_chars):
            continue

        docs.append(
            ConvoDoc(
                convo_id=cid,
                title=title or "(untitled)",
                created_at=created,
                updated_at=updated,
                doc_text=text,
                doc_len=len(text),
            )
        )
    return docs


def run_clustering(
    docs: List[ConvoDoc],
    k: Optional[int],
    max_features: int,
    min_df: int,
    max_df: float,
    ngram_max: int,
    extra_stopwords: List[str],
    random_state: int,
) -> Tuple[List[int], Dict[int, List[str]], Dict[int, str]]:
    n = len(docs)
    k_final = choose_k(n, k)

    corpus = [normalize_for_vectorizer(d.doc_text) for d in docs]

    stop_words = set(extra_stopwords or [])
    # scikit-learn will combine english stop words if "english"; we add ours via stop_words list
    vectorizer = TfidfVectorizer(
        stop_words="english",
        min_df=int(min_df),
        max_df=float(max_df),
        max_features=int(max_features),
        ngram_range=(1, int(ngram_max)),
    )

    X = vectorizer.fit_transform(corpus)

    model = KMeans(n_clusters=k_final, n_init="auto", random_state=int(random_state))
    cluster_ids = model.fit_predict(X).tolist()

    top_terms = top_terms_per_cluster(vectorizer, model, top_n=14)
    labels = {cid: label_from_terms(top_terms.get(cid, [])) for cid in range(k_final)}
    return cluster_ids, top_terms, labels


# ----------------------------
# Output writing
# ----------------------------


def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def write_csv_labeled(outdir: Path, docs: List[ConvoDoc], cluster_ids: List[int], labels: Dict[int, str]) -> None:
    path = outdir / "conversations_labeled.csv"
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["conversation_id", "title", "created_at", "updated_at", "cluster_id", "cluster_label", "doc_len"])
        for d, cid in zip(docs, cluster_ids):
            w.writerow([d.convo_id, d.title, d.created_at or "", d.updated_at or "", cid, labels.get(cid, ""), d.doc_len])


def write_top_terms(outdir: Path, top_terms: Dict[int, List[str]], labels: Dict[int, str]) -> None:
    path = outdir / "clusters_top_terms.csv"
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["cluster_id", "cluster_label", "top_terms"])
        for cid in sorted(top_terms.keys()):
            w.writerow([cid, labels.get(cid, ""), ", ".join(top_terms.get(cid, []))])


def write_theme_files(outdir: Path, docs: List[ConvoDoc], cluster_ids: List[int], labels: Dict[int, str]) -> Dict[int, List[ConvoDoc]]:
    buckets: Dict[int, List[ConvoDoc]] = defaultdict(list)
    for d, cid in zip(docs, cluster_ids):
        buckets[int(cid)].append(d)

    # Stable ordering inside each theme: newest first when possible
    def sort_key(doc: ConvoDoc) -> Tuple[int, str]:
        # Put None dates last
        return (0 if doc.created_at else 1, (doc.created_at or ""))

    for cid, items in buckets.items():
        items.sort(key=sort_key, reverse=True)

    for cid in sorted(buckets.keys()):
        fname = outdir / f"theme_{cid:02d}.md"
        with fname.open("w", encoding="utf-8") as f:
            f.write(f"# Theme {cid:02d}: {labels.get(cid, '')}\n\n")
            f.write(f"- Conversations: {len(buckets[cid])}\n\n")
            for d in buckets[cid]:
                # include id so you can locate it later
                dt = d.created_at or ""
                f.write(f"- **{d.title}**  \n")
                if dt:
                    f.write(f"  - {dt}\n")
                f.write(f"  - id: `{d.convo_id}`\n")
            f.write("\n")
    return buckets


def write_summary(outdir: Path, buckets: Dict[int, List[ConvoDoc]], labels: Dict[int, str], top_terms: Dict[int, List[str]], meta: Dict[str, Any]) -> None:
    path = outdir / "themes_summary.md"
    with path.open("w", encoding="utf-8") as f:
        f.write("# ChatGPT Theme Summary\n\n")
        f.write(f"Generated: {datetime.utcnow().isoformat(timespec='seconds')}Z\n\n")

        f.write("## Run settings\n")
        for k, v in meta.items():
            f.write(f"- **{k}**: {v}\n")
        f.write("\n")

        if not buckets:
            f.write("## Result\n\n")
            f.write("No conversations were included in clustering.\n\n")
            f.write("Common reasons:\n")
            f.write("- Your export contains messages but extraction returned empty (format mismatch)\n")
            f.write("- `--min-chars` filtered everything out\n")
            f.write("- Conversations are extremely short\n")
            f.write("\n")
            return

        f.write("## Themes\n\n")
        items = sorted(buckets.items(), key=lambda kv: len(kv[1]), reverse=True)
        for cid, convos in items:
            f.write(f"### Theme {cid:02d}: {labels.get(cid, '')}\n\n")
            f.write(f"- Count: **{len(convos)}**\n")
            terms = top_terms.get(cid, [])
            if terms:
                f.write(f"- Top terms: `{', '.join(terms[:12])}`\n")
            f.write(f"- File: `theme_{cid:02d}.md`\n\n")


# ----------------------------
# CLI
# ----------------------------


def main() -> None:
    ap = argparse.ArgumentParser(description="Cluster ChatGPT conversations.json into themes (offline).")
    ap.add_argument("conversations_json", help="Path to conversations.json from ChatGPT export")
    ap.add_argument("--outdir", default="theme_output", help="Output directory (default: theme_output)")
    ap.add_argument("--k", type=int, default=None, help="Number of themes (default: auto)")
    ap.add_argument("--min-chars", type=int, default=200, help="Minimum conversation text length (default: 200)")
    ap.add_argument("--include-assistant", action="store_true", help="Include assistant messages (default: user-only)")
    ap.add_argument("--include-system", action="store_true", help="Include system messages")
    ap.add_argument("--include-tool", action="store_true", help="Include tool/function messages")
    ap.add_argument("--max-features", type=int, default=25000, help="TF-IDF max features (default: 25000)")
    ap.add_argument("--min-df", type=int, default=3, help="TF-IDF min_df (default: 3)")
    ap.add_argument("--max-df", type=float, default=0.5, help="TF-IDF max_df (default: 0.5)")
    ap.add_argument("--ngram-max", type=int, default=2, help="Use up to N-grams (default: 2)")
    ap.add_argument("--random-state", type=int, default=42, help="Random seed (default: 42)")
    ap.add_argument(
        "--extra-stopwords",
        default="",
        help="Comma-separated extra stopwords to add (in addition to built-ins)",
    )
    args = ap.parse_args()

    in_path = Path(args.conversations_json).expanduser().resolve()
    if not in_path.exists():
        raise SystemExit(f"File not found: {in_path}")

    outdir = Path(args.outdir).expanduser().resolve()
    ensure_dir(outdir)

    convos = load_conversations(in_path)
    if not convos:
        # Always write a summary so output isn't mysteriously empty
        write_summary(
            outdir,
            buckets={},
            labels={},
            top_terms={},
            meta={
                "input": str(in_path),
                "error": "No conversations found in JSON (unexpected format?)",
            },
        )
        raise SystemExit("No conversations found in the JSON. Export format might differ.")

    docs = build_docs(
        convos,
        include_assistant=bool(args.include_assistant),
        include_system=bool(args.include_system),
        include_tool=bool(args.include_tool),
        min_chars=int(args.min_chars),
    )

    if not docs:
        # Write a summary explaining why
        write_summary(
            outdir,
            buckets={},
            labels={},
            top_terms={},
            meta={
                "input": str(in_path),
                "k": args.k,
                "min_chars": args.min_chars,
                "include_assistant": args.include_assistant,
                "include_system": args.include_system,
                "include_tool": args.include_tool,
                "note": "No documents survived extraction/filtering.",
            },
        )
        print("No conversations survived filtering/extraction.")
        print(f"Wrote summary: {outdir / 'themes_summary.md'}")
        return

    extra = [w.strip().lower() for w in (args.extra_stopwords or "").split(",") if w.strip()]
    extra_stop = sorted(set(DEFAULT_STOP_EXTRA) | set(extra))

    cluster_ids, top_terms, labels = run_clustering(
        docs=docs,
        k=args.k,
        max_features=args.max_features,
        min_df=args.min_df,
        max_df=args.max_df,
        ngram_max=args.ngram_max,
        extra_stopwords=extra_stop,
        random_state=args.random_state,
    )

    write_csv_labeled(outdir, docs, cluster_ids, labels)
    write_top_terms(outdir, top_terms, labels)
    buckets = write_theme_files(outdir, docs, cluster_ids, labels)

    write_summary(
        outdir,
        buckets=buckets,
        labels=labels,
        top_terms=top_terms,
        meta={
            "input": str(in_path),
            "conversations_total": len(convos),
            "conversations_used": len(docs),
            "k": choose_k(len(docs), args.k),
            "min_chars": args.min_chars,
            "include_assistant": args.include_assistant,
            "include_system": args.include_system,
            "include_tool": args.include_tool,
            "vectorizer": f"tfidf(max_features={args.max_features}, min_df={args.min_df}, max_df={args.max_df}, ngram_max={args.ngram_max})",
        },
    )

    print("Wrote:")
    print(" -", outdir / "conversations_labeled.csv")
    print(" -", outdir / "clusters_top_terms.csv")
    print(" -", outdir / "themes_summary.md")
    print(f" - theme_XX.md files ({len(buckets)} themes)")
    print(f"\nConversations used: {len(docs)} / {len(convos)}")


if __name__ == "__main__":
    main()
