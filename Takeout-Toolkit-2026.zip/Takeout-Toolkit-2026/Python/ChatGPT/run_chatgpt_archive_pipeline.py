#!/usr/bin/env python3
"""
run_chatgpt_archive_pipeline.py

Chains:
  1) theme_miner.py
  2) analyze_chatgpt_export.py
  3) (optional) launches inboxGPT_app_fast_batch.py via Streamlit

Usage examples:
  python run_chatgpt_archive_pipeline.py conversations.json
  python run_chatgpt_archive_pipeline.py conversations.json --k 12 --min-chars 200
  python run_chatgpt_archive_pipeline.py conversations.json --run-ui
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path


def run(cmd: list[str], cwd: Path | None = None) -> None:
    print("\n==>", " ".join(cmd))
    p = subprocess.run(cmd, cwd=str(cwd) if cwd else None)
    if p.returncode != 0:
        raise SystemExit(f"Step failed (exit code {p.returncode}): {' '.join(cmd)}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("conversations_json", help="Path to ChatGPT export conversations.json")
    ap.add_argument("--k", type=int, default=12, help="Number of themes/clusters (default: 12)")
    ap.add_argument("--min-chars", type=int, default=200, help="Theme Miner min conversation chars (default: 200)")
    ap.add_argument("--include-assistant", action="store_true", help="Theme Miner: include assistant text")
    ap.add_argument("--out-root", default="pipeline_out", help="Root output folder (default: pipeline_out)")
    ap.add_argument("--run-ui", action="store_true", help="Launch Streamlit InboxGPT fast batch UI at the end")
    ap.add_argument("--streamlit-port", type=int, default=8501, help="Port for Streamlit (default: 8501)")
    ap.add_argument("--scripts-dir", default=".", help="Folder containing the three scripts (default: current folder)")
    args = ap.parse_args()

    conv_path = Path(args.conversations_json).expanduser().resolve()
    if not conv_path.exists():
        raise SystemExit(f"File not found: {conv_path}")

    scripts_dir = Path(args.scripts_dir).expanduser().resolve()
    theme_miner = scripts_dir / "theme_miner.py"
    analyzer = scripts_dir / "analyze_chatgpt_export.py"
    inboxgpt = scripts_dir / "inboxGPT_app_fast_batch.py"

    missing = [p for p in (theme_miner, analyzer, inboxgpt) if not p.exists()]
    if missing:
        raise SystemExit(
            "Missing scripts:\n" + "\n".join(f"- {p}" for p in missing) +
            "\n\nPut all three scripts in the same folder, or pass --scripts-dir."
        )

    # Make a timestamped run folder so outputs don't collide.
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_root = Path(args.out_root).expanduser().resolve()
    out_run = out_root / f"run_{stamp}"
    out_theme = out_run / "theme_miner"
    out_analyze = out_run / "analyze_export"
    out_theme.mkdir(parents=True, exist_ok=True)
    out_analyze.mkdir(parents=True, exist_ok=True)

    # Prefer using the current python executable to avoid PATH surprises.
    py = sys.executable

    # --- 1) Theme Miner (Option B) ---
    cmd1 = [py, str(theme_miner), str(conv_path), "--k", str(args.k), "--min-chars", str(args.min_chars), "--outdir", str(out_theme)]
    if args.include_assistant:
        cmd1.append("--include-assistant")
    run(cmd1)

    # --- 2) Analyzer (extra CSVs + cluster summary) ---
    cmd2 = [py, str(analyzer), str(conv_path), "--k", str(args.k), "--outdir", str(out_analyze)]
    run(cmd2)

    # --- 3) Optional: launch Streamlit UI ---
    if args.run_ui:
        streamlit = shutil.which("streamlit")
        if not streamlit:
            raise SystemExit(
                "Streamlit not found. Install it with:\n"
                "  python -m pip install -U streamlit\n"
                "Then rerun with --run-ui"
            )
        cmd3 = [
            streamlit, "run", str(inboxgpt),
            "--server.port", str(args.streamlit_port),
        ]
        run(cmd3)

    print("\nDone.")
    print("Outputs:")
    print(f" - Theme Miner: {out_theme}")
    print(f" - Analyzer:    {out_analyze}")
    if args.run_ui:
        print(f" - Streamlit UI should be running on http://localhost:{args.streamlit_port}")


if __name__ == "__main__":
    main()
