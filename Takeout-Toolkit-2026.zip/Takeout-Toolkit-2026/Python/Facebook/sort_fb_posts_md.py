#!/usr/bin/env python3

"""
Sort Facebook posts stored in a Markdown file by date.

This is useful when you have a Markdown file containing many posts
(e.g., exported/converted Facebook posts), and each post includes a line
like:

    **Date:** Saturday, August 12, 2017 at 12:05am PDT

The script:
- splits the file into individual posts (based on a separator)
- extracts the date from each post
- sorts posts chronologically (oldest -> newest by default)
- writes a new Markdown file with the sorted posts

Usage:
    python sort_fb_posts_md.py fb-posts.md

Custom output:
    python sort_fb_posts_md.py fb-posts.md -o sorted.md

Newest first:
    python sort_fb_posts_md.py fb-posts.md --desc

Custom post separator (advanced):
    python sort_fb_posts_md.py fb-posts.md --separator "\\n\\n\\n\\n"

Notes:
- If some posts don't contain a parseable **Date:** line, they will be placed
  at the beginning (oldest) by default (or end if using --desc).
"""

import argparse
import re
from datetime import datetime
from pathlib import Path
import sys


DATE_REGEX = re.compile(
    r"\*\*Date:\*\*\s*([A-Za-z]+,\s+[A-Za-z]+\s+\d{1,2},\s+\d{4}\s+at\s+\d{1,2}:\d{2}[ap]m\s+[A-Z]+)"
)


def extract_date(post_text: str):
    """
    Extract a datetime from a post block.

    Expected format:
        **Date:** Saturday, August 12, 2017 at 12:05am PDT

    We strip the final timezone token (PDT/PST/etc.) before parsing.
    """
    match = DATE_REGEX.search(post_text)
    if not match:
        return None

    date_with_tz = match.group(1).strip()
    # Remove last token (timezone). Example: "... 12:05am PDT" -> "... 12:05am"
    cleaned = date_with_tz.rsplit(" ", 1)[0]

    try:
        return datetime.strptime(cleaned, "%A, %B %d, %Y at %I:%M%p")
    except ValueError:
        return None


def sort_posts(posts, descending: bool):
    """
    Sort posts by extracted date.
    Posts without a parseable date get a sentinel value so ordering is stable.
    """
    sentinel = datetime.max if descending else datetime.min

    return sorted(
        posts,
        key=lambda post: extract_date(post) or sentinel,
        reverse=descending
    )


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Sort a Markdown file of Facebook posts by the embedded '**Date:**' field.\n\n"
            "Designed for files where each post is a block of text and includes a Date line like:\n"
            "  **Date:** Saturday, August 12, 2017 at 12:05am PDT\n\n"
            "Posts are split using a separator (default: four newlines)."
        ),
        formatter_class=argparse.RawTextHelpFormatter
    )

    parser.add_argument(
        "input_md",
        type=Path,
        help="Input Markdown file containing posts"
    )

    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=Path("sorted_facebook_posts.md"),
        help="Output Markdown file (default: sorted_facebook_posts.md)"
    )

    parser.add_argument(
        "--desc",
        action="store_true",
        help="Sort newest -> oldest instead of oldest -> newest"
    )

    parser.add_argument(
        "--separator",
        default="\n\n\n\n",
        help=(
            "String used to split posts (default: \\n\\n\\n\\n).\n"
            "If your file uses a different spacing between posts, change this."
        )
    )

    args = parser.parse_args()

    if not args.input_md.exists():
        print(f"Error: File not found: {args.input_md}", file=sys.stderr)
        sys.exit(1)

    content = args.input_md.read_text(encoding="utf-8")

    posts = content.split(args.separator)
    # Drop empty blocks (common if the file starts/ends with separators)
    posts = [p for p in posts if p.strip()]

    if not posts:
        print("Error: No posts found after splitting. Check your --separator.", file=sys.stderr)
        sys.exit(2)

    sorted_posts = sort_posts(posts, descending=args.desc)

    args.output.write_text(args.separator.join(sorted_posts), encoding="utf-8")

    # Stats: how many had parseable dates
    dated = sum(1 for p in sorted_posts if extract_date(p) is not None)
    undated = len(sorted_posts) - dated

    print(f"✅ Sorted {len(sorted_posts)} posts")
    print(f"🗓️  Posts with parseable dates: {dated}")
    if undated:
        print(f"⚠️  Posts without parseable dates: {undated} (kept, but sorted using sentinel placement)")
    print(f"📄 Saved to {args.output}")


if __name__ == "__main__":
    main()
