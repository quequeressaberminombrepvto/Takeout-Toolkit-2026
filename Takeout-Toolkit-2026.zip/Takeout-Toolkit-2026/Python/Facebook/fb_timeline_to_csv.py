#!/usr/bin/env python3

"""
Facebook Timeline HTML -> CSV extractor

This script reads a Facebook "timeline.htm" (from an export or archive),
extracts post text and associated timestamps, and saves the result as a CSV
for analysis (Excel, Google Sheets, pandas, etc.).

Important note:
Facebook export HTML structure can vary between versions/regions.
This script uses common selectors ("div.meta" for timestamps and
"div.comment" for post text). If your export differs, you may need to adjust
the selectors using the --post-selector and --time-selector options.

Usage:
    python fb_timeline_to_csv.py timeline.htm

Save with a custom output name:
    python fb_timeline_to_csv.py timeline.htm -o timeline.csv

Customize selectors (advanced):
    python fb_timeline_to_csv.py timeline.htm \
        --post-selector "div.comment" \
        --time-selector "div.meta"
"""

import argparse
from pathlib import Path
import sys

import pandas as pd
from bs4 import BeautifulSoup


DEFAULT_POST_SELECTOR = "div.comment"
DEFAULT_TIME_SELECTOR = "div.meta"


def extract_rows(html_path: Path, post_selector: str, time_selector: str):
    """Extract (post, timestamp) rows from the given HTML file."""
    html_content = html_path.read_text(encoding="utf-8")
    soup = BeautifulSoup(html_content, "html.parser")

    posts = soup.select(post_selector)
    times = soup.select(time_selector)

    if not posts or not times:
        return [], len(posts), len(times)

    # Zip pairs by position (same approach as your original script)
    rows = []
    for post_el, time_el in zip(posts, times):
        rows.append(
            {
                "post": post_el.get_text(strip=True),
                "timestamp": time_el.get_text(strip=True),
            }
        )

    return rows, len(posts), len(times)


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Extract posts + timestamps from a Facebook timeline HTML file and save as CSV.\n\n"
            "Tip: If you get 0 rows, your HTML export likely uses different CSS selectors.\n"
            "Try opening timeline.htm in a browser, inspect an element, and pass custom selectors."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )

    parser.add_argument(
        "html_file",
        type=Path,
        hel
