#!/usr/bin/env python3

"""
Convert facebook_timeline.json into TimelineJS-compatible JSON.

What this does
--------------
If you have a JSON file of Facebook posts like:

    [
      {"date": "2017-08-12T00:05:00", "content": "Post text here"},
      ...
    ]

This script converts it into the JSON structure used by TimelineJS:
https://timeline.knightlab.com/

Each post becomes an "event" with a start_date and text fields.

Usage
-----
Basic:
    python fb_json_to_timelinejs.py facebook_timeline.json

Custom output file:
    python fb_json_to_timelinejs.py facebook_timeline.json -o timeline_data.json

Change headline truncation length:
    python fb_json_to_timelinejs.py facebook_timeline.json --headline-len 80

Include a stable id field per event:
    python fb_json_to_timelinejs.py facebook_timeline.json --add-id

Notes
-----
- Input dates must be ISO 8601 (e.g., "2017-08-12T00:05:00").
- TimelineJS months are 1-12; this script uses that.
- Posts missing date/content are skipped.
"""

import argparse
import json
from datetime import datetime
from pathlib import Path
import sys


def to_event(post: dict, headline_len: int, add_id: bool, idx: int):
    date_raw = post.get("date")
    content = post.get("content", "")

    if not isinstance(date_raw, str) or not content:
        return None

    try:
        date = datetime.fromisoformat(date_raw)
    except ValueError:
        return None

    headline = content.strip().replace("\n", " ")
    if len(headline) > headline_len:
        headline = headline[:headline_len].rstrip() + "…"

    event = {
        "start_date": {
            "year": date.year,
            "month": date.month,
            "day": date.day,
            "hour": date.hour,
            "minute": date.minute,
        },
        "text": {
            "headline": headline,
            "text": content,
        },
    }

    if add_id:
        event["unique_id"] = f"fb_post_{idx:06d}"

    return event


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Convert a simple Facebook timeline JSON export into TimelineJS format.\n\n"
            "Input must be a JSON list of objects with keys: 'date' (ISO string) and 'content'.\n"
            "Output is a TimelineJS JSON object with an 'events' list."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )

    parser.add_argument(
        "input_json",
        type=Path,
        help="Input JSON file (e.g., facebook_timeline.json)",
    )

    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=Path("timeline_data.json"),
        help="Output TimelineJS JSON file (default: timeline_data.json)",
    )

    parser.add_argument(
        "--headline-len",
        type=int,
        default=50,
        help="Max headline length before truncation (default: 50)",
    )

    parser.add_argument(
        "--add-id",
        action="store_true",
        help="Add a unique_id field to each event (useful for debugging/merging)",
    )

    args = parser.parse_args()

    if not args.input_json.exists():
        print(f"Error: File not found: {args.input_json}", file=sys.stderr)
        sys.exit(1)

    posts = json.loads(args.input_json.read_text(encoding="utf-8"))

    if not isinstance(posts, list):
        print("Error: Expected the input JSON to be a list of posts.", file=sys.stderr)
        sys.exit(2)

    timeline_data = {"events": []}

    skipped = 0
    for idx, post in enumerate(posts):
        if not isinstance(post, dict):
            skipped += 1
            continue

        event = to_event(post, args.headline_len, args.add_id, idx)
        if event is None:
            skipped += 1
            continue

        timeline_data["events"].append(event)

    args.output.write_text(
        json.dumps(timeline_data, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(f"✅ Converted {len(timeline_data['events'])} posts into TimelineJS events")
    if skipped:
        print(f"⚠️  Skipped {skipped} entries (missing/invalid date or content)")
    print(f"📄 Saved to {args.output}")


if __name__ == "__main__":
    main()
