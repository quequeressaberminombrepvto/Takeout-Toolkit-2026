#!/usr/bin/env python3

"""
Extract Facebook timeline posts from a timeline HTML export
and save them as structured JSON.

Usage:
    python fb_timeline_to_json.py timeline.htm
"""

import argparse
import json
from datetime import datetime
from bs4 import BeautifulSoup
from pathlib import Path
import sys


def parse_timeline(html_path: Path):
    """Parse Facebook timeline HTML and return list of posts."""
    with html_path.open("r", encoding="utf-8") as file:
        soup = BeautifulSoup(file, "html.parser")

    posts = []

    for p in soup.find_all("p"):
        meta = p.find("div", class_="meta")
        comment = p.find("div", class_="comment")

        if not meta:
            continue

        date_text = meta.get_text(strip=True)

        # Remove timezone suffix (e.g., PST)
        cleaned_date_text = date_text.rsplit(" ", 1)[0]

        try:
            date_iso = datetime.strptime(
                cleaned_date_text,
                "%A, %B %d, %Y at %I:%M%p"
            ).isoformat()
        except ValueError:
            # Skip entries with unexpected date formats
            continue

        content = (
            comment.get_text(strip=True)
            if comment
            else p.get_text().replace(date_text, "").strip()
        )

        posts.append({
            "date": date_iso,
            "content": content
        })

    return posts


def main():
    parser = argparse.ArgumentParser(
        description="Convert Facebook timeline HTML to JSON"
    )
    parser.add_argument(
        "html_file",
        type=Path,
        help="Path to timeline.htm file"
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=Path("facebook_timeline.json"),
        help="Output JSON file (default: facebook_timeline.json)"
    )

    args = parser.parse_args()

    if not args.html_file.exists():
        print(f"Error: File not found: {args.html_file}", file=sys.stderr)
        sys.exit(1)

    posts = parse_timeline(args.html_file)

    args.output.write_text(
        json.dumps(posts, indent=4, ensure_ascii=False),
        encoding="utf-8"
    )

    print(f"✅ Extracted {len(posts)} posts")
    print(f"📄 Saved to {args.output}")


if __name__ == "__main__":
    main()
