#!/usr/bin/env python3
"""
Run the Facebook timeline.html -> TimelineJS pipeline (single command).

Expected folder layout (same folder):
  timeline.html (or timeline.htm)
  fb_timeline_to_json.py
  fb_timeline_filter.py
  fb_json_to_timeline.py
  run_fb_timeline_pipeline.py   <-- this file

Pipeline order:
  1) timeline.html -> facebook_timeline.json               (fb_timeline_to_json.py)
  2) facebook_timeline.json -> facebook_timeline_clean.json (fb_timeline_filter.py)
  3) facebook_timeline_clean.json -> timeline_data.json     (fb_json_to_timeline.py)

Usage:
  python -u run_fb_timeline_pipeline.py timeline.html --keep-intermediate
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

S1_HTML_TO_JSON = "fb_timeline_to_json.py"
S2_FILTER_JSON = "fb_timeline_filter.py"
S3_JSON_TO_TIMELINE = "fb_json_to_timeline.py"


def die(msg: str, code: int = 1) -> None:
    print(f"ERROR: {msg}", file=sys.stderr, flush=True)
    raise SystemExit(code)


def require_file(path: Path, what: str) -> None:
    if not path.exists():
        die(f"Missing {what}: {path}")
    if path.is_file() and path.stat().st_size == 0:
        die(f"{what} exists but is empty: {path}")


def run(cmd: list[str], cwd: Path) -> None:
    pretty = " ".join(cmd)
    print(f"\n-> {pretty}", flush=True)
    p = subprocess.run(cmd, cwd=str(cwd))
    if p.returncode != 0:
        die(f"Command failed (exit {p.returncode}): {pretty}", p.returncode)


def main() -> None:
    print("=== Facebook Timeline pipeline starting ===", flush=True)

    ap = argparse.ArgumentParser(
        description="Run the Facebook timeline.html -> TimelineJS pipeline.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    ap.add_argument("timeline_html", type=Path, help="Path to timeline.html / timeline.htm")
    ap.add_argument("--out-dir", type=Path, default=None, help="Optional output directory (relative to the HTML folder unless absolute)")
    ap.add_argument("--filter", nargs="*", default=[], help="Extra filter phrases (passed to fb_timeline_filter.py)")
    ap.add_argument("--filter-file", type=Path, default=None, help="Text file with one filter phrase per line (passed to fb_timeline_filter.py)")
    ap.add_argument("--headline-len", type=int, default=50, help="TimelineJS headline length (passed to fb_json_to_timeline.py)")
    ap.add_argument("--add-id", action="store_true", help="Add a unique_id per event (passed to fb_json_to_timeline.py)")
    ap.add_argument("--keep-intermediate", action="store_true", help="Keep intermediate JSON files")
    args = ap.parse_args()

    html_path = args.timeline_html
    require_file(html_path, "timeline HTML")

    # Everything is assumed to be in the same folder as the timeline HTML.
    workdir = html_path.resolve().parent
    print(f"Working folder: {workdir}", flush=True)
    print(f"Using Python: {sys.executable}", flush=True)

    # Scripts in same folder
    s1 = workdir / S1_HTML_TO_JSON
    s2 = workdir / S2_FILTER_JSON
    s3 = workdir / S3_JSON_TO_TIMELINE
    require_file(s1, "script fb_timeline_to_json.py")
    require_file(s2, "script fb_timeline_filter.py")
    require_file(s3, "script fb_json_to_timeline.py")

    # Output directory
    if args.out_dir is None:
        out_dir = workdir
    else:
        out_dir = args.out_dir if args.out_dir.is_absolute() else (workdir / args.out_dir)
        out_dir = out_dir.resolve()
        out_dir.mkdir(parents=True, exist_ok=True)

    extracted_json = out_dir / "facebook_timeline.json"
    cleaned_json = out_dir / "facebook_timeline_clean.json"
    timelinejs_json = out_dir / "timeline_data.json"

    py = sys.executable

    # 1) HTML -> JSON
    run([py, str(s1), str(html_path), "-o", str(extracted_json)], cwd=workdir)
    require_file(extracted_json, "output facebook_timeline.json")

    # 2) Filter JSON
    cmd2 = [py, str(s2), str(extracted_json), "-o", str(cleaned_json)]
    if args.filter:
        cmd2 += ["--filter", *args.filter]
    if args.filter_file:
        ff = args.filter_file if args.filter_file.is_absolute() else (workdir / args.filter_file).resolve()
        require_file(ff, "filter file")
        cmd2 += ["--filter-file", str(ff)]
    run(cmd2, cwd=workdir)
    require_file(cleaned_json, "output facebook_timeline_clean.json")

    # 3) JSON -> TimelineJS JSON
    cmd3 = [
        py,
        str(s3),
        str(cleaned_json),
        "-o",
        str(timelinejs_json),
        "--headline-len",
        str(args.headline_len),
    ]
    if args.add_id:
        cmd3.append("--add-id")
    run(cmd3, cwd=workdir)
    require_file(timelinejs_json, "output timeline_data.json")

    # Cleanup
    if not args.keep_intermediate:
        extracted_json.unlink(missing_ok=True)
        cleaned_json.unlink(missing_ok=True)

    print("\n✅ Done.", flush=True)
    print(f"📄 Created: {timelinejs_json}", flush=True)


if __name__ == "__main__":
    main()
