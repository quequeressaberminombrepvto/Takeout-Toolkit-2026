#!/usr/bin/env python3

"""
Cluster Facebook timeline statuses (or other short posts) into topic-like groups.

What this does
--------------
Given a Facebook timeline HTML file (often named timeline.htm or timeline.html),
this script:
1) extracts post text from the HTML (default selector: div.comment)
2) cleans the text (lowercase + punctuation removal)
3) vectorizes posts with TF-IDF
4) clusters them using KMeans
5) prints groups to the terminal (optionally saves JSON)

Why it’s useful
---------------
Facebook timelines often contain thousands of posts. Clustering can help you:
- find recurring themes you posted about
- separate “life updates” from “quotes”, “rants”, “music”, etc.
- identify repetitive/automated style posts (sometimes)

Usage
-----
Basic:
    python fb_status_cluster.py timeline.htm

Choose number of clusters:
    python fb_status_cluster.py timeline.htm -k 8

Save groups to JSON:
    python fb_status_cluster.py timeline.htm -k 8 --out groups.json

Advanced: use a different CSS selector if your export differs:
    python fb_status_cluster.py timeline.htm --selector "div.comment"

Notes
-----
- Clustering is unsupervised: group numbers are arbitrary.
- Results depend on the number of clusters (-k) and the text in your timeline.
"""

import argparse
import json
import re
import sys
from pathlib import Path

from bs4 import BeautifulSoup
from sklearn.cluster import KMeans
from sklearn.feature_extraction.text import TfidfVectorizer


DEFAULT_SELECTOR = "div.comment"


def extract_texts(html_path: Path, selector: str) -> list[str]:
    """Extract post/status text from an HTML file using a CSS selector."""
    soup = BeautifulSoup(html_path.read_text(encoding="utf-8"), "html.parser")
    elements = soup.select(selector)
    return [el.get_text(" ", strip=True) for el in elements]


def preprocess_text(text: str) -> str:
    """Basic cleanup: lowercase + remove non-word chars."""
    text = text.lower()
    text = re.sub(r"\W+", " ", text)
    return text.strip()


def cluster_texts(texts: list[str], n_clusters: int, random_state: int = 42):
    """
    Vectorize with TF-IDF and cluster with KMeans.
    Returns a dict: cluster_label -> list[text]
    """
    vectorizer = TfidfVectorizer(stop_words="english")
    X = vectorizer.fit_transform(texts)

    model = KMeans(n_clusters=n_clusters, random_state=random_state, n_init="auto")
    labels = model.fit_predict(X)

    groups: dict[int, list[str]] = {}
    for text, label in zip(texts, labels):
        groups.setdefault(int(label), []).append(text)

    return groups


def print_groups(groups: dict[int, list[str]], limit_per_group: int | None = None):
    """Print groups to stdout with optional per-group limit."""
    for label in sorted(groups.keys()):
        texts = groups[label]
        print(f"\n=== Group {label} ({len(texts)} items) ===")
        if limit_per_group is None:
            for t in texts:
                print(f"- {t}")
        else:
            for t in texts[:limit_per_group]:
                print(f"- {t}")
            if len(texts) > limit_per_group:
                print(f"... ({len(texts) - limit_per_group} more)")


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Cluster Facebook timeline statuses/posts into themes using TF-IDF + KMeans.\n\n"
            "Default extraction selector is 'div.comment' (common in Facebook exports).\n"
            "If you get 0 extracted posts, try --selector with a different CSS selector."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )

    parser.add_argument(
        "html_file",
        type=Path,
        help="Path to Facebook timeline HTML file (e.g., timeline.htm)",
    )

    parser.add_argument(
        "-k",
        "--clusters",
        type=int,
        default=5,
        help="Number of clusters to create (default: 5)",
    )

    parser.add_argument(
        "--selector",
        default=DEFAULT_SELECTOR,
        help=f'CSS selector used to extract post text (default: "{DEFAULT_SELECTOR}")',
    )

    parser.add_argument(
        "--min-length",
        type=int,
        default=1,
        help="Drop posts shorter than this many characters after preprocessing (default: 1)",
    )

    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Limit how many example posts to print per group (default: print all)",
    )

    parser.add_argument(
        "--out",
        type=Path,
        default=None,
        help="Optional output JSON path to save grouped results",
    )

    args = parser.parse_args()

    if not args.html_file.exists():
        print(f"Error: File not found: {args.html_file}", file=sys.stderr)
        sys.exit(1)

    raw_texts = extract_texts(args.html_file, args.selector)

    if not raw_texts:
        print("⚠️  No posts extracted.", file=sys.stderr)
        print(f"Selector used: {args.selector}", file=sys.stderr)
        print(
            "Try opening the HTML in a browser and inspecting a post element, then pass\n"
            'a selector like: --selector "div.comment" (or whatever matches your file).',
            file=sys.stderr,
        )
        sys.exit(2)

    texts = [preprocess_text(t) for t in raw_texts]
    texts = [t for t in texts if len(t) >= args.min_length]

    if len(texts) < args.clusters:
        print(
            f"Error: Not enough posts ({len(texts)}) to form {args.clusters} clusters.",
            file=sys.stderr,
        )
        sys.exit(3)

    groups = cluster_texts(texts, n_clusters=args.clusters)

    print(f"✅ Extracted {len(raw_texts)} posts (kept {len(texts)} after preprocessing)")
    print(f"🧠 Clustered into {args.clusters} groups")
    print_groups(groups, limit_per_group=args.limit)

    if args.out:
        # Save as { "0": [...], "1": [...], ... } for JSON friendliness
        serializable = {str(k): v for k, v in groups.items()}
        args.out.write_text(json.dumps(serializable, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"\n📄 Saved groups to {args.out}")


if __name__ == "__main__":
    main()
