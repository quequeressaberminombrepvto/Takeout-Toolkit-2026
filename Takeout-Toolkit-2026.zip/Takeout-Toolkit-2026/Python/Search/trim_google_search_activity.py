#!/usr/bin/env python3

"""
Trim Google Takeout "My Activity" Search JSON to only actual search queries.

What this does
--------------
Google Takeout exports "My Activity" data that contains many kinds of entries.
For Search history, the JSON often includes items where:
  titleUrl starts with: https://www.google.com/search?q=...

This script filters your MyActivity.json to keep ONLY entries that look like
Google search queries (i.e., the ones with that /search?q= URL).

Optionally, it can also extract the query text (the "q" parameter) into a
simpler JSON list for easier analysis later.

Usage
-----
Basic:
    python trim_google_search_activity.py MyActivity.json

Custom output filename:
    python trim_google_search_activity.py MyActivity.json -o filtered.json

Also extract query strings into a second file:
    python trim_google_search_activity.py MyActivity.json --queries-out queries.json

Notes
-----
- This script runs offline and does not upload your data anywhere.
- Google Takeout formats can vary slightly; this targets the common structure.
"""

import argparse
import json
from pathlib import Path
from urllib.parse import urlparse, parse_qs


SEARCH_PREFIX = "https://www.google.com/search?q="


def extract_query_from_url(url: str) -> str:
    """Extract the 'q' query parameter from a Google search URL, if present."""
    try:
        parsed = urlparse(url)
        qs = parse_qs(parsed.query)
        q = qs.get("q", [""])[0]
        return q
    except Exception:
        return ""


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Filter Google Takeout My Activity Search JSON to keep only entries that are actual Google searches.\n\n"
            "Keeps entries where 'titleUrl' starts with:\n"
            f"  {SEARCH_PREFIX}"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )

    parser.add_argument(
        "input_json",
        type=Path,
        help="Path to MyActivity.json (from Google Takeout > My Activity > Search)",
    )

    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=Path("filtered_google_search_data.json"),
        help="Filtered output JSON file (default: filtered_google_search_data.json)",
    )

    parser.add_argument(
        "--queries-out",
        type=Path,
        default=None,
        help=(
            "Optional: also write a simplified JSON file containing just extracted search queries.\n"
            "Each item includes: time, query, titleUrl"
        ),
    )

    args = parser.parse_args()

    if not args.input_json.exists():
        raise SystemExit(f"Error: File not found: {args.input_json}")

    data = json.loads(args.input_json.read_text(encoding="utf-8"))

    if not isinstance(data, list):
        raise SystemExit("Error: Expected the input JSON to be a list of activity entries.")

    filtered = [
        entry for entry in data
        if entry.get("titleUrl", "").startswith(SEARCH_PREFIX)
    ]

    args.output.write_text(
        json.dumps(filtered, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(f"✅ Kept {len(filtered)} search-query entries (out of {len(data)})")
    print(f"📄 Saved filtered data to: {args.output}")

    if args.queries_out:
        simplified = []
        for entry in filtered:
            url = entry.get("titleUrl", "")
            simplified.append({
                "time": entry.get("time", ""),
                "query": extract_query_from_url(url),
                "titleUrl": url,
                "title": entry.get("title", ""),
            })

        args.queries_out.write_text(
            json.dumps(simplified, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        print(f"🔎 Saved extracted queries to: {args.queries_out}")


if __name__ == "__main__":
    main()
