#!/usr/bin/env python3
"""
make_keyword_groups.py

Create pipeline_output/keyword_groups.json from pipeline_output/extracted_queries.json.

Input format expected (from trim_google_search_activity.py --queries-out):
[
  {"time": "...", "query": "...", "titleUrl": "...", "title": "..."},
  ...
]
"""

from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict
from pathlib import Path
import sys


DEFAULT_STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "by", "for", "from",
    "has", "he", "in", "is", "it", "its", "of", "on", "that", "the",
    "to", "was", "were", "will", "with"
}


def tokenize(term: str) -> list[str]:
    return re.findall(r"\b\w+\b", term.lower())


def main() -> None:
    p = argparse.ArgumentParser(description="Build keyword_groups.json from extracted_queries.json")
    p.add_argument("--input", type=Path, required=True, help="Path to extracted_queries.json")
    p.add_argument("--output", type=Path, required=True, help="Path to write keyword_groups.json")
    p.add_argument("--min-group-size", type=int, default=4, help="Minimum group size (default: 4)")
    p.add_argument("--stopword", action="append", default=[], help="Extra stopwords to ignore (repeatable)")
    args = p.parse_args()

    if not args.input.exists():
        print(f"Error: input not found: {args.input}", file=sys.stderr)
        sys.exit(1)

    data = json.loads(args.input.read_text(encoding="utf-8", errors="replace"))
    if not isinstance(data, list):
        print("Error: expected a JSON list", file=sys.stderr)
        sys.exit(2)

    stopwords = set(DEFAULT_STOPWORDS) | {s.strip().lower() for s in args.stopword if s.strip()}

    word_to_terms: dict[str, set[str]] = defaultdict(set)

    for item in data:
        if not isinstance(item, dict):
            continue
        q = (item.get("query") or "").strip()
        if not q:
            continue

        words = [w for w in tokenize(q) if w not in stopwords]
        for w in words:
            word_to_terms[w].add(q)

    groups = {w: sorted(list(terms)) for w, terms in word_to_terms.items() if len(terms) >= args.min_group_size}

    # Sort keys by group size (largest first) for nicer browsing
    groups_sorted = dict(sorted(groups.items(), key=lambda kv: len(kv[1]), reverse=True))

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(groups_sorted, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"✅ Wrote {len(groups_sorted)} groups to {args.output}")


if __name__ == "__main__":
    main()
