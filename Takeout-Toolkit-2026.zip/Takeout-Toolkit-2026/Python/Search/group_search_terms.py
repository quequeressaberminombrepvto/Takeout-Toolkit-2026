#!/usr/bin/env python3

"""
Group search terms into large keyword-based clusters.

What this does
--------------
Given a plain text file containing one search term per line, this script
groups searches by shared meaningful words. It’s useful for quickly spotting
your “big themes” in search history, like:

- repeated searches about the same topic
- recurring interests, fixations, projects, or concerns
- keyword clusters that show up again and again

How it works (simple + transparent)
-----------------------------------
1) Tokenize each search term into words
2) Remove stopwords (common words like "the", "and", "to")
3) Build groups for each remaining word
4) Keep only groups with at least N terms (default: 4)

Usage
-----
Basic:
    python group_search_terms.py plain-search-terms.txt

Change minimum group size:
    python group_search_terms.py plain-search-terms.txt --min-group-size 6

Write results to JSON:
    python group_search_terms.py plain-search-terms.txt --json-out groups.json

Add your own stopwords (repeatable):
    python group_search_terms.py plain-search-terms.txt --stopword "reddit" --stopword "youtube"

Notes
-----
- This is a lightweight heuristic, not topic modeling.
- A term can appear in multiple groups (one per keyword it contains).
"""

import argparse
import json
import re
from collections import defaultdict
from pathlib import Path
import sys


DEFAULT_STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "by", "for", "from",
    "has", "he", "in", "is", "it", "its", "of", "on", "that", "the",
    "to", "was", "were", "will", "with"
}


def read_lines(path: Path) -> list[str]:
    return [line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def tokenize(term: str) -> list[str]:
    return re.findall(r"\b\w+\b", term.lower())


def group_search_terms(search_terms: list[str], stopwords: set[str], min_group_size: int):
    # word -> list of terms containing it
    word_to_terms: dict[str, list[str]] = defaultdict(list)

    for term in search_terms:
        words = [w for w in tokenize(term) if w not in stopwords]
        for w in words:
            word_to_terms[w].append(term)

    # Convert to word -> unique set of terms, then filter by size
    groups: dict[str, list[str]] = {}
    for word, terms in word_to_terms.items():
        unique_terms = sorted(set(terms))
        if len(unique_terms) >= min_group_size:
            groups[word] = unique_terms

    return groups


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Group search terms by shared keywords to find large recurring themes.\n\n"
            "Input: a text file with ONE search term per line.\n"
            "Output: printed groups (and optionally JSON)."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )

    parser.add_argument(
        "input_file",
        type=Path,
        help="Text file containing one search term per line",
    )

    parser.add_argument(
        "--min-group-size",
        type=int,
        default=4,
        help="Only keep keyword groups with at least this many terms (default: 4)",
    )

    parser.add_argument(
        "--stopword",
        action="append",
        default=[],
        help="Add extra stopwords to ignore (repeatable)",
    )

    parser.add_argument(
        "--json-out",
        type=Path,
        default=None,
        help="Optional: write grouped results to a JSON file",
    )

    args = parser.parse_args()

    if not args.input_file.exists():
        print(f"Error: File not found: {args.input_file}", file=sys.stderr)
        sys.exit(1)

    stopwords = set(DEFAULT_STOPWORDS) | {s.strip().lower() for s in args.stopword if s.strip()}

    search_terms = read_lines(args.input_file)
    if not search_terms:
        print("Error: Input file had no non-empty lines.", file=sys.stderr)
        sys.exit(2)

    groups = group_search_terms(search_terms, stopwords, args.min_group_size)

    # Print groups sorted by size (largest first)
    items = sorted(groups.items(), key=lambda kv: len(kv[1]), reverse=True)

    print(f"✅ Read {len(search_terms)} search terms")
    print(f"🧠 Found {len(groups)} keyword groups with size ≥ {args.min_group_size}\n")

    for word, terms in items:
        print(f"Word: {word} ({len(terms)} terms)")
        for t in terms:
            print(f"  - {t}")
        print()

    if args.json_out:
        args.json_out.write_text(json.dumps(groups, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"📄 Saved JSON to {args.json_out}")


if __name__ == "__main__":
    main()
