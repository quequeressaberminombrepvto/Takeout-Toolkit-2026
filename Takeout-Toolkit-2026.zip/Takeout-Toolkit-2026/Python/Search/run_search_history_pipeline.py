#!/usr/bin/env python3
"""
Run Google Search Takeout pipeline end-to-end (clean outputs, no staging).

Outputs written to ./pipeline_output (or --out-dir):
  - filtered_google_search_data.json
  - extracted_queries.json
  - searches_by_month.csv
  - searches_by_month/YYYY-MM.json (monthly files)
  - keyword_groups.json   <-- REQUIRED by Themes tab in the Streamlit explorer

Usage:
  python run_search_history_pipeline.py --json MyActivity.json
  python run_search_history_pipeline.py --json MyActivity.json --use-recursive-filter
  python run_search_history_pipeline.py --json MyActivity.json --app

Notes:
- Requires these scripts to be in the same folder as this file:
    trim_google_search_activity.py
    filter_searches_recursive.py
    extract_search_history_by_month.py   (UPDATED version that supports --input/--out-dir)
    make_keyword_groups.py              (NEW helper that builds keyword_groups.json)
    search_history_app.py               (optional upload-based browser)
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


def run(cmd: list[str], cwd: Path | None = None) -> None:
    print("\n▶ " + " ".join(cmd))
    r = subprocess.run(cmd, cwd=str(cwd) if cwd else None)
    if r.returncode != 0:
        raise SystemExit(r.returncode)


def ensure_exists(path: Path, label: str) -> None:
    if not path.exists():
        raise SystemExit(f"Error: {label} not found: {path}")


def script_path(here: Path, name: str) -> Path:
    p = here / name
    ensure_exists(p, f"Script {name}")
    return p


def main() -> None:
    here = Path(__file__).resolve().parent

    parser = argparse.ArgumentParser(description="Run Google Search History pipeline (clean outputs, no staging).")
    parser.add_argument("--json", type=Path, required=True, help="Path to MyActivity.json (Google Takeout)")
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("pipeline_output"),
        help="Output folder (default: pipeline_output)",
    )

    parser.add_argument(
        "--use-recursive-filter",
        action="store_true",
        help="Also run recursive filter for nested/ugly JSON inputs",
    )

    parser.add_argument(
        "--min-group-size",
        type=int,
        default=4,
        help="Minimum group size for keyword groups (default: 4)",
    )

    parser.add_argument(
        "--app",
        action="store_true",
        help="Launch the upload-based Streamlit browser (search_history_app.py) at the end",
    )

    args = parser.parse_args()

    ensure_exists(args.json, "Input JSON")
    args.out_dir.mkdir(parents=True, exist_ok=True)

    # Required scripts
    trim_script = script_path(here, "trim_google_search_activity.py")
    recursive_script = script_path(here, "filter_searches_recursive.py")
    by_month_script = script_path(here, "extract_search_history_by_month.py")
    make_groups_script = script_path(here, "make_keyword_groups.py")
    app_script = script_path(here, "search_history_app.py")

    # Clean, user-facing outputs
    filtered_json = args.out_dir / "filtered_google_search_data.json"
    extracted_queries_json = args.out_dir / "extracted_queries.json"
    groups_json = args.out_dir / "keyword_groups.json"

    # 1) Trim to actual searches
    run([
        sys.executable, str(trim_script),
        str(args.json),
        "-o", str(filtered_json),
        "--queries-out", str(extracted_queries_json),
    ])

    current_json = filtered_json

    # 2) Optional recursive filter (if JSON is nested or weird)
    if args.use_recursive_filter:
        recursive_out = args.out_dir / "filtered_search_activity_recursive.json"
        run([
            sys.executable, str(recursive_script),
            str(current_json),
            "-o", str(recursive_out),
        ])
        current_json = recursive_out

        # If we ran recursive filter, we should also rebuild extracted_queries.json
        # from current_json (because extracted_queries_json was generated from the trimmed file).
        # Easiest: rerun trim script on the recursive output to regenerate extracted queries.
        # However, trim script expects MyActivity list format; if recursive output is already
        # a flat list of matching dicts, it's usually safe to pass through.
        run([
            sys.executable, str(trim_script),
            str(current_json),
            "-o", str(filtered_json),
            "--queries-out", str(extracted_queries_json),
        ])
        current_json = filtered_json

    # 3) Extract month CSV + monthly JSON files (no staging; script supports CLI args)
    run([
        sys.executable, str(by_month_script),
        "--input", str(current_json),
        "--out-dir", str(args.out_dir),
        "--csv-name", "searches_by_month.csv",
        "--monthly-dir-name", "searches_by_month",
    ])

    # 4) Build keyword_groups.json (Themes tab depends on this)
    run([
        sys.executable, str(make_groups_script),
        "--input", str(extracted_queries_json),
        "--output", str(groups_json),
        "--min-group-size", str(args.min_group_size),
    ])

    print("\n✅ Pipeline complete.")
    print(f"   Output folder: {args.out_dir.resolve()}")
    print("   Files created/updated:")
    print(f"   - {filtered_json.name}")
    print(f"   - {extracted_queries_json.name}")
    print(f"   - searches_by_month.csv")
    print(f"   - searches_by_month/ (monthly JSON files)")
    print(f"   - {groups_json.name}")

    # 5) Optional: launch upload-based Streamlit browser (not your hard-locked explorer)
    if args.app:
        run(["streamlit", "run", str(app_script)])


if __name__ == "__main__":
    main()
