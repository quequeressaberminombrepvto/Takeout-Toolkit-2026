#!/usr/bin/env python3

"""
Extract anchor text from an HTML file (e.g., Google Takeout MyActivity.html).

What this does
--------------
Google Takeout "My Activity" exports are often HTML pages with many links.
This script extracts the visible text inside <a> tags (anchor text), which can
be useful for:
- quickly getting a plain-text list of visited titles
- building datasets for later analysis
- cleaning/previewing large Takeout HTML files without a browser

Usage
-----
Basic:
    python extract_anchor_text.py MyActivity.html

Custom output:
    python extract_anchor_text.py MyActivity.html -o extracted_links.txt

Deduplicate:
    python extract_anchor_text.py MyActivity.html --dedupe

Also include href URLs (tab-separated):
    python extract_anchor_text.py MyActivity.html --include-hrefs -o links.tsv

Notes
-----
- Runs offline.
- Output is plain text by default (one line per link text).
- If --include-hrefs is used, output becomes TSV: "text<TAB>url"
"""

import argparse
from pathlib import Path
import sys

from bs4 import BeautifulSoup


def extract_links(html_path: Path, include_hrefs: bool):
    soup = BeautifulSoup(html_path.read_text(encoding="utf-8"), "html.parser")

    results = []
    for a in soup.find_all("a"):
        text = a.get_text(strip=True)
        if not text:
            continue

        if include_hrefs:
            href = (a.get("href") or "").strip()
            results.append((text, href))
        else:
            results.append(text)

    return results


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Extract visible anchor text from an HTML file (e.g., Google Takeout MyActivity.html).\n\n"
            "By default outputs one line per <a> tag's visible text.\n"
            "Use --include-hrefs to output TSV rows: text<TAB>href"
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )

    parser.add_argument(
        "input_html",
        type=Path,
        help="Path to input HTML file (e.g., MyActivity.html)",
    )

    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=Path("extracted_links.txt"),
        help="Output file path (default: extracted_links.txt)",
    )

    parser.add_argument(
        "--dedupe",
        action="store_true",
        help="Remove duplicates while preserving first-seen order",
    )

    parser.add_argument(
        "--include-hrefs",
        action="store_true",
        help="Include href URLs (outputs TSV: text<TAB>href)",
    )

    args = parser.parse_args()

    if not args.input_html.exists():
        print(f"Error: File not found: {args.input_html}", file=sys.stderr)
        sys.exit(1)

    extracted = extract_links(args.input_html, include_hrefs=args.include_hrefs)

    if args.dedupe:
        seen = set()
        deduped = []
        for item in extracted:
            key = item if isinstance(item, str) else (item[0], item[1])
            if key in seen:
                continue
            seen.add(key)
            deduped.append(item)
        extracted = deduped

    if args.include_hrefs:
        # TSV output
        lines = [f"{text}\t{href}" for (text, href) in extracted]
    else:
        lines = extracted  # list[str]

    args.output.write_text("\n".join(lines), encoding="utf-8")

    print(f"✅ Extracted {len(extracted)} links")
    print(f"📄 Saved to {args.output}")


if __name__ == "__main__":
    main()
