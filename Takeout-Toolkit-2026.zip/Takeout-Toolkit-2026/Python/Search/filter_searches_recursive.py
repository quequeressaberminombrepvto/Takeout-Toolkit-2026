#!/usr/bin/env python3

"""
Recursively filter Google Search entries from a nested JSON file.

What this does
--------------
Some Google Takeout JSON files (or derived datasets) are deeply nested
(dicts inside lists inside dicts). This script walks the entire structure
recursively and extracts ONLY the objects where a given key's value starts
with a specific prefix.

Default use case:
- Extract Google Search activity entries where:
    titleUrl starts with "https://www.google.com/search?q="

This is useful when:
- Your JSON is not a flat list
- Search activity is embedded inside larger activity objects
- You want to isolate *only* actual Google searches

Usage
-----
Basic:
    python filter_searches_recursive.py searches.json

Custom output:
    python filter_searches_recursive.py searches.json -o filtered.json

Change key or prefix (advanced):
    python filter_searches_recursive.py data.json \
        --key titleUrl \
        --startswith "https://www.google.com/search?q="

Notes
-----
- Runs completely offline
- Output is always a flat list of matching objects
- Original JSON structure is not modified
"""

import argparse
import json
from pathlib import Path
import sys
from typing import Any, List


DEFAULT_KEY = "titleUrl"
DEFAULT_PREFIX = "https://www.google.com/search?q="


def filter_nested_data(data: Any, key: str, value_startswith: str) -> List[dict]:
    """
    Recursively search nested data structures and collect dicts
    where data[key] starts with value_startswith.
    """
    results = []

    if isinstance(data, dict):
        value = data.get(key)
        if isinstance(value, str) and value.startswith(value_startswith):
            results.append(data)

        for v in data.values():
            results.extend(filter_nested_data(v, key, value_startswith))

    elif isinstance(data, list):
        for item in data:
            results.extend(filter_nested_data(item, key, value_startswith))

    return results


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Recursively extract Google Search activity entries from nested JSON.\n\n"
            "By default, keeps objects where:\n"
            f"  {DEFAULT_KEY} starts with {DEFAULT_PREFIX}\n\n"
            "The result is written as a flat JSON list."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
    )

    parser.add_argument(
        "input_json",
        type=Path,
        help="Path to input JSON file (possibly deeply nested)",
    )

    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=Path("filtered_search_activity.json"),
        help="Output JSON file (default: filtered_search_activity.json)",
    )

    parser.add_argument(
        "--key",
        default=DEFAULT_KEY,
        help=f"Dictionary key to check (default: {DEFAULT_KEY})",
    )

    parser.add_argument(
        "--startswith",
        default=DEFAULT_PREFIX,
        help=f"Required prefix value must start with (default: {DEFAULT_PREFIX})",
    )

    args = parser.parse_args()

    if not args.input_json.exists():
        print(f"Error: File not found: {args.input_json}", file=sys.stderr)
        sys.exit(1)

    data = json.loads(args.input_json.read_text(encoding="utf-8"))

    filtered = filter_nested_data(data, args.key, args.startswith)

    args.output.write_text(
        json.dumps(filtered, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print(f"✅ Found {len(filtered)} matching entries")
    print(f"📄 Saved to {args.output}")


if __name__ == "__main__":
    main()
