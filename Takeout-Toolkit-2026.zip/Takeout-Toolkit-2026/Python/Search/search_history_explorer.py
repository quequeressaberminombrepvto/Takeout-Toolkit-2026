#!/usr/bin/env python3
"""
Search History Explorer (Streamlit) — HARD-LOCKED

This app ONLY loads pipeline outputs from a folder named `pipeline_output`
that sits next to this file:

  toolkit/
    search_history_explorer.py
    pipeline_output/
      searches_by_month.csv
      keyword_groups.json (optional)
      searches_by_month/ (optional monthly JSON files)

Run:
  streamlit run search_history_explorer.py

For no-clunk launch, use launch_explorer.py
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Dict, Any, List

import pandas as pd
import streamlit as st


# ----------------------------
# Helpers
# ----------------------------

def locked_output_dir() -> Path:
    """Hard-locked: pipeline_output must be next to this script."""
    return (Path(__file__).resolve().parent / "pipeline_output").resolve()


def safe_read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8", errors="replace"))


def coerce_datetime(df: pd.DataFrame) -> pd.DataFrame:
    # Try a few likely columns
    for col in ("datetime", "time", "timestamp", "dt"):
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce", utc=True).dt.tz_convert(None)
            if col != "datetime":
                df = df.rename(columns={col: "datetime"})
            break

    # If CSV has date + time columns
    if "datetime" not in df.columns and "date" in df.columns and "time" in df.columns:
        df["datetime"] = pd.to_datetime(
            df["date"].astype(str) + " " + df["time"].astype(str),
            errors="coerce",
        )

    if "datetime" in df.columns:
        df["date"] = pd.to_datetime(df["datetime"], errors="coerce").dt.date
        df["year"] = pd.to_datetime(df["datetime"], errors="coerce").dt.year
        df["month"] = pd.to_datetime(df["datetime"], errors="coerce").dt.month
        df["hour"] = pd.to_datetime(df["datetime"], errors="coerce").dt.hour
        df["weekday"] = pd.to_datetime(df["datetime"], errors="coerce").dt.day_name()

    return df


def normalize_query(text: str) -> str:
    s = (text or "").strip()
    s = re.sub(r"\s+", " ", s)
    return s


@st.cache_data(show_spinner=False)
def load_csv(csv_path: Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path, encoding="utf-8", on_bad_lines="skip")

    # Normalize likely column names
    rename_map = {}
    if "query" not in df.columns and "title" in df.columns:
        rename_map["title"] = "query"
    if "url" not in df.columns and "titleUrl" in df.columns:
        rename_map["titleUrl"] = "url"
    if rename_map:
        df = df.rename(columns=rename_map)

    if "query" in df.columns:
        df["query"] = df["query"].astype(str).map(normalize_query)

    df = coerce_datetime(df)

    # Derive year_month if missing
    if "year_month" not in df.columns and "datetime" in df.columns:
        df["year_month"] = pd.to_datetime(df["datetime"], errors="coerce").dt.strftime("%Y-%m")

    # Sort newest first
    if "datetime" in df.columns:
        df = df.sort_values("datetime", ascending=False, na_position="last").reset_index(drop=True)

    return df


@st.cache_data(show_spinner=False)
def load_keyword_groups(groups_path: Path) -> Dict[str, List[str]]:
    data = safe_read_json(groups_path)
    if isinstance(data, dict):
        clean: Dict[str, List[str]] = {}
        for k, v in data.items():
            if isinstance(k, str) and isinstance(v, list):
                clean[k] = [str(x) for x in v if str(x).strip()]
        return clean
    return {}


def list_month_json_files(month_dir: Path) -> List[Path]:
    if not month_dir.exists():
        return []
    return sorted(month_dir.glob("*.json"))


def format_int(n: int) -> str:
    return f"{n:,}"


def top_n_counts(series: pd.Series, n: int = 30) -> pd.DataFrame:
    s = series.dropna().astype(str)
    vc = s.value_counts().head(n)
    return pd.DataFrame({"item": vc.index, "count": vc.values})


def filtered_df(df: pd.DataFrame, year: int | None, month: int | None, keyword: str) -> pd.DataFrame:
    out = df
    if year is not None and "year" in out.columns:
        out = out[out["year"] == year]
    if month is not None and "month" in out.columns:
        out = out[out["month"] == month]
    if keyword.strip() and "query" in out.columns:
        kw = keyword.strip()
        out = out[out["query"].str.contains(kw, case=False, na=False)]
    return out


# ----------------------------
# App
# ----------------------------

def main():
    st.set_page_config(page_title="Search History Explorer", layout="wide")
    st.title("🔎 Search History Explorer")

    out_dir = locked_output_dir()
    csv_path = out_dir / "searches_by_month.csv"
    groups_path = out_dir / "keyword_groups.json"
    month_dir = out_dir / "searches_by_month"

    # Hard-locked status banner
    st.caption(f"Data folder (locked): `{out_dir}`")

    # Validate required output
    if not out_dir.exists():
        st.error(
            "Missing `pipeline_output/` next to this app.\n\n"
            "Expected:\n"
            f"- {out_dir}\n\n"
            "Fix:\n"
            "1) Run your pipeline\n"
            "2) Ensure `pipeline_output/` is in the same folder as `search_history_explorer.py`"
        )
        st.stop()

    if not csv_path.exists():
        st.error(
            "Missing required file: `searches_by_month.csv`\n\n"
            f"Expected:\n- {csv_path}\n\n"
            "Fix:\nRun your pipeline and make sure it produces `pipeline_output/searches_by_month.csv`."
        )
        st.stop()

    with st.spinner("Loading data..."):
        df = load_csv(csv_path)

    groups = load_keyword_groups(groups_path) if groups_path.exists() else {}
    month_files = list_month_json_files(month_dir)

    tab_overview, tab_timeline, tab_themes, tab_months, tab_exports = st.tabs(
        ["Overview", "Timeline", "Themes", "Month Browser", "Export"]
    )

    # Overview
    with tab_overview:
        st.subheader("Dataset Summary")

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Total searches (rows)", format_int(len(df)))

        if "date" in df.columns and df["date"].notna().any():
            min_date = pd.to_datetime(df["date"], errors="coerce").min()
            max_date = pd.to_datetime(df["date"], errors="coerce").max()
            c2.metric("Date range", f"{min_date.date()} → {max_date.date()}" if pd.notna(min_date) and pd.notna(max_date) else "—")
        else:
            c2.metric("Date range", "—")

        c3.metric("Years", format_int(df["year"].nunique()) if "year" in df.columns else "—")
        c4.metric("Monthly JSON files", format_int(len(month_files)))

        st.divider()

        colA, colB = st.columns([2, 1])

        with colA:
            st.subheader("Quick Search")
            keyword = st.text_input("Filter by keyword (query contains)", value="")
            years = sorted([int(y) for y in df["year"].dropna().unique()]) if "year" in df.columns else []
            year = st.selectbox("Year", options=["All"] + years, index=0)
            months = list(range(1, 13))
            month = st.selectbox("Month", options=["All"] + months, index=0)

            year_val = None if year == "All" else int(year)
            month_val = None if month == "All" else int(month)

            fdf = filtered_df(df, year_val, month_val, keyword)

            st.caption(f"Showing **{format_int(len(fdf))}** rows (table shows up to 500)")
            show_cols = [c for c in ["datetime", "query", "url", "year_month"] if c in fdf.columns]
            st.dataframe(fdf[show_cols].head(500), use_container_width=True, hide_index=True)

        with colB:
            st.subheader("Top Queries (in current filter)")
            if "query" in fdf.columns and not fdf.empty:
                st.dataframe(top_n_counts(fdf["query"], n=25), use_container_width=True, hide_index=True)
            else:
                st.info("No query data available for the current filter.")

    # Timeline
    with tab_timeline:
        st.subheader("Search Volume Over Time")

        if "year_month" not in df.columns or df["year_month"].isna().all():
            st.warning("No `year_month` column found/derived. Timeline view needs dates.")
        else:
            counts = (
                df.dropna(subset=["year_month"])
                .groupby("year_month")
                .size()
                .reset_index(name="count")
                .sort_values("year_month")
            )
            st.line_chart(counts.set_index("year_month")["count"])

            st.divider()
            st.subheader("Activity by Day of Week")
            if "weekday" in df.columns:
                dow = df.dropna(subset=["weekday"]).groupby("weekday").size().reset_index(name="count")
                order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
                dow["weekday"] = pd.Categorical(dow["weekday"], categories=order, ordered=True)
                dow = dow.sort_values("weekday")
                st.bar_chart(dow.set_index("weekday")["count"])
            else:
                st.info("No weekday column available.")

            st.divider()
            st.subheader("Activity by Hour")
            if "hour" in df.columns:
                hr = df.dropna(subset=["hour"]).groupby("hour").size().reset_index(name="count").sort_values("hour")
                st.bar_chart(hr.set_index("hour")["count"])
            else:
                st.info("No hour column available.")

    # Themes
    with tab_themes:
        st.subheader("Keyword Theme Groups")

        if not groups:
            st.info("No `keyword_groups.json` found. Run your pipeline with `--group` to generate theme clusters.")
        else:
            items = sorted(groups.items(), key=lambda kv: len(kv[1]), reverse=True)
            left, right = st.columns([1, 2])

            with left:
                options = [f"{k} ({len(v)})" for k, v in items]
                chosen = st.selectbox("Group", options=options, index=0)
                chosen_key = chosen.split(" (")[0]
                terms = groups.get(chosen_key, [])

                st.write(f"Total terms: **{format_int(len(terms))}**")
                st.download_button(
                    "⬇️ Download this group as .txt",
                    data="\n".join(terms) + "\n",
                    file_name=f"group_{chosen_key}.txt",
                    mime="text/plain",
                )

            with right:
                st.caption("Terms")
                st.dataframe(pd.DataFrame({"term": terms}), use_container_width=True, hide_index=True)

                if "query" in df.columns and terms:
                    st.divider()
                    st.caption("Rows matching any term (contains) — showing up to 500")
                    sample_terms = terms[:50]
                    pattern = "|".join(re.escape(t) for t in sample_terms if t.strip())
                    if pattern:
                        match_df = df[df["query"].str.contains(pattern, case=False, na=False)]
                        st.write(f"Matches: **{format_int(len(match_df))}**")
                        show_cols = [c for c in ["datetime", "query", "url"] if c in match_df.columns]
                        st.dataframe(match_df[show_cols].head(500), use_container_width=True, hide_index=True)

    # Month Browser
    with tab_months:
        st.subheader("Month Browser (JSON files)")

        if not month_files:
            st.info("No monthly JSON files found in `pipeline_output/searches_by_month/`.")
        else:
            month_labels = [p.stem for p in month_files]  # "YYYY-MM"
            chosen = st.selectbox("Choose month", options=month_labels, index=max(0, len(month_labels) - 1))

            chosen_path = month_dir / f"{chosen}.json"
            data = safe_read_json(chosen_path)
            if not isinstance(data, list):
                st.error("Monthly JSON file wasn't a list.")
            else:
                rows = []
                for item in data:
                    if not isinstance(item, dict):
                        continue
                    rows.append({
                        "time": item.get("time", ""),
                        "title": item.get("title", ""),
                        "url": item.get("titleUrl", item.get("url", "")),
                    })
                mdf = pd.DataFrame(rows)
                if "time" in mdf.columns:
                    mdf["datetime"] = pd.to_datetime(mdf["time"], errors="coerce")
                    mdf = mdf.sort_values("datetime", ascending=False, na_position="last")

                st.write(f"Rows: **{format_int(len(mdf))}**")
                st.dataframe(mdf.head(1000), use_container_width=True, hide_index=True)

                st.download_button(
                    "⬇️ Download this month as CSV",
                    data=mdf.to_csv(index=False),
                    file_name=f"searches_{chosen}.csv",
                    mime="text/csv",
                )

    # Export
    with tab_exports:
        st.subheader("Export Filtered Views")

        keyword = st.text_input("Keyword (query contains)", value="", key="export_kw")
        years = sorted([int(y) for y in df["year"].dropna().unique()]) if "year" in df.columns else []
        year = st.selectbox("Year", options=["All"] + years, index=0, key="export_year")
        months = list(range(1, 13))
        month = st.selectbox("Month", options=["All"] + months, index=0, key="export_month")

        year_val = None if year == "All" else int(year)
        month_val = None if month == "All" else int(month)

        fdf = filtered_df(df, year_val, month_val, keyword)

        st.write(f"Rows in export: **{format_int(len(fdf))}**")

        export_cols = st.multiselect(
            "Columns to include",
            options=list(fdf.columns),
            default=[c for c in ["datetime", "query", "url", "year_month"] if c in fdf.columns] or list(fdf.columns)[:5],
        )

        export_df = fdf[export_cols] if export_cols else fdf

        st.download_button(
            "⬇️ Download filtered CSV",
            data=export_df.to_csv(index=False),
            file_name="filtered_searches.csv",
            mime="text/csv",
        )

        st.download_button(
            "⬇️ Download filtered JSON",
            data=export_df.to_json(orient="records", indent=2, date_format="iso"),
            file_name="filtered_searches.json",
            mime="application/json",
        )

        st.divider()
        st.caption("This app is hard-locked to the sibling `pipeline_output/` folder.")


if __name__ == "__main__":
    main()
