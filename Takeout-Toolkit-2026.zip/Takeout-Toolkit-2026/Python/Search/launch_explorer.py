#!/usr/bin/env python3
"""
Launch the Search History Explorer with minimal clunk.

- Starts Streamlit on localhost
- Opens the browser automatically
- Keeps running until the user closes the app

Run:
  python launch_explorer.py

Optional:
  python launch_explorer.py --out-dir path/to/pipeline_output
  python launch_explorer.py --port 8501
"""

from __future__ import annotations

import argparse
import os
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path


def is_port_free(port: int) -> bool:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("127.0.0.1", port))
        return True
    except OSError:
        return False


def pick_port(preferred: int) -> int:
    if is_port_free(preferred):
        return preferred
    for p in range(preferred + 1, preferred + 50):
        if is_port_free(p):
            return p
    return preferred


def open_browser_when_ready(url: str, delay_seconds: float = 1.2) -> None:
    time.sleep(delay_seconds)
    try:
        webbrowser.open(url, new=2)
    except Exception:
        pass


def main() -> None:
    parser = argparse.ArgumentParser(description="Launch the Search History Explorer (Streamlit) with auto-open.")
    parser.add_argument("--out-dir", type=str, default=None, help="Path to pipeline_output folder (optional)")
    parser.add_argument("--port", type=int, default=8501, help="Preferred port (default: 8501)")
    args = parser.parse_args()

    here = Path(__file__).resolve().parent
    app_path = here / "search_history_explorer.py"
    if not app_path.exists():
        raise SystemExit(f"Missing app file: {app_path}")

    port = pick_port(args.port)
    url = f"http://localhost:{port}"

    # Streamlit configuration via env vars (reduces prompts + noise)
    env = dict(os.environ)
    env["STREAMLIT_BROWSER_GATHER_USAGE_STATS"] = "false"
    env["STREAMLIT_SERVER_HEADLESS"] = "true"
    env["STREAMLIT_SERVER_PORT"] = str(port)
    env["STREAMLIT_SERVER_ADDRESS"] = "127.0.0.1"

    # Pass the output dir into the app via env var, but keep the app robust even without it.
    if args.out_dir:
        env["PIPELINE_OUTPUT_DIR"] = args.out_dir

    # Auto-open browser shortly after start
    t = threading.Thread(target=open_browser_when_ready, args=(url,), daemon=True)
    t.start()

    cmd = [
        sys.executable, "-m", "streamlit", "run", str(app_path),
        "--server.port", str(port),
        "--server.address", "127.0.0.1",
    ]

    # Keep a terminal window if launched via python; when packaged with PyInstaller --noconsole, it won’t show.
    proc = subprocess.Popen(cmd, env=env)
    try:
        proc.wait()
    except KeyboardInterrupt:
        pass
    finally:
        try:
            proc.terminate()
        except Exception:
            pass


if __name__ == "__main__":
    main()
