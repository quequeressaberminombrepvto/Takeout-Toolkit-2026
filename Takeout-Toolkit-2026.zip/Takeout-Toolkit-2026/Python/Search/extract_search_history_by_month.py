#!/usr/bin/env python3
import argparse
import json
import csv
from datetime import datetime
from collections import defaultdict
from pathlib import Path


def load_activity(path: Path):
    return json.loads(path.read_text(encoding="utf-8", errors="replace"))


def main():
    parser = argparse.ArgumentParser(
        description="Extract Google MyActivity Search history into a CSV + per-month JSON files."
    )
    parser.add_argument(
        "--input",
        type=Path,
        required=True,
        help="Input JSON file (usually filtered MyActivity.json list)",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path("pipeline_output"),
        help="Output directory (default: pipeline_output)",
    )
    parser.add_argument(
        "--csv-name",
        type=str,
        default="searches_by_month.csv",
        help="CSV filename (default: searches_by_month.csv)",
    )
    parser.add_argument(
        "--monthly-dir-name",
        type=str,
        default="searches_by_month",
        help="Monthly JSON directory name (default: searches_by_month)",
    )
    args = parser.parse_args()

    if not args.input.exists():
        raise SystemExit(f"Error: input file not found: {args.input}")

    args.out_dir.mkdir(parents=True, exist_ok=True)
    monthly_dir = args.out_dir / args.monthly_dir_name
    monthly_dir.mkdir(parents=True, exist_ok=True)

    data = load_activity(args.input)

    if not isinstance(data, list):
        raise SystemExit("Error: Expected input JSON to be a list of activity entries.")

    csv_rows = []
    by_month = defaultdict(list)

    for item in data:
        # Common case: items have header == "Search"
        # (If you already trimmed by titleUrl prefix, header might still exist; if not, we won't require it.)
        # If you WANT to enforce header == Search, uncomment:
        # if item.get("header") != "Search":
        #     continue

        time_str = item.get("time")
        if not time_str:
            continue

        time_clean = time_str.replace("Z", "+00:00")
        try:
            dt = datetime.fromisoformat(time_clean)
        except Exception:
            continue

        year_month = dt.strftime("%Y-%m")
        date_str = dt.date().isoformat()
        time_of_day = dt.time().isoformat(timespec="seconds")

        title = item.get("title", "")
        url = item.get("titleUrl", item.get("url", ""))

        csv_rows.append([year_month, date_str, time_of_day, title, url])

        item_with_month = dict(item)
        item_with_month["year_month"] = year_month
        by_month[year_month].append(item_with_month)

    # Write CSV
    csv_path = args.out_dir / args.csv_name
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["year_month", "date", "time", "title", "url"])
        w.writerows(csv_rows)

    # Write monthly JSON files
    for ym, items in by_month.items():
        out_path = monthly_dir / f"{ym}.json"
        out_path.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"✅ Wrote {len(csv_rows)} search entries to {csv_path}")
    print(f"✅ Monthly JSON files saved in {monthly_dir.resolve()}")


if __name__ == "__main__":
    main()
