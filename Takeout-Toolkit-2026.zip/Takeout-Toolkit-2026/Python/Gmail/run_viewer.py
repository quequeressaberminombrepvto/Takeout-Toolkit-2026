#!/usr/bin/env python3
from __future__ import annotations
import http.server, socketserver, webbrowser, socket, os
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPORT_DIR = HERE / "report"

def pick_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]

def main():
    if not REPORT_DIR.exists():
        raise SystemExit(f"Missing report folder: {REPORT_DIR}\nRun build_viewer.py first.")
    port = pick_port()
    os.chdir(str(REPORT_DIR))
    handler = http.server.SimpleHTTPRequestHandler
    with socketserver.TCPServer(("127.0.0.1", port), handler) as httpd:
        url = f"http://127.0.0.1:{port}/"
        print(f"Serving: {REPORT_DIR}")
        print(f"Open: {url}")
        try:
            webbrowser.open(url)
        except Exception:
            pass
        print("Press Ctrl+C to stop.")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nStopping.")
if __name__ == "__main__":
    main()
