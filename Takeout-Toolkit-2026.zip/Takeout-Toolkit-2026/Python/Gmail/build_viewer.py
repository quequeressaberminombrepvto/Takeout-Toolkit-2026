#!/usr/bin/env python3
from __future__ import annotations
import argparse, shutil
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPORT_DATA = HERE / "report" / "data"

EXPECTED = [
    "inbox_metadata.csv",
    "relationships_raw.csv",
    "relationships_filtered.csv",
    "relationships_clean.csv",
    "core_timeline.csv",
]

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--from-output", default=str(HERE / "output"), help="Pipeline output folder (default: ./output)")
    args = p.parse_args()

    out_dir = Path(args.from_output).resolve()
    REPORT_DATA.mkdir(parents=True, exist_ok=True)

    copied, missing = 0, []
    for name in EXPECTED:
        src = out_dir / name
        dst = REPORT_DATA / name
        if src.exists():
            shutil.copy2(src, dst)
            copied += 1
            print(f"Copied: {src} -> {dst}")
        else:
            missing.append(name)

    print(f"\nDone. Copied {copied}/{len(EXPECTED)} expected CSVs into {REPORT_DATA}")
    if missing:
        print("Missing:")
        for m in missing:
            print(" -", m)
        print("\nTip: run your pipeline first to generate these outputs.")
if __name__ == "__main__":
    main()
