#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
PY = sys.executable
OUT = HERE / "output"
OUT.mkdir(exist_ok=True)

FILES = {
    "inbox": OUT / "inbox_metadata.csv",
    "raw": OUT / "relationships_raw.csv",
    "filtered": OUT / "relationships_filtered.csv",
    "clean": OUT / "relationships_clean.csv",
    "core": OUT / "core_timeline.csv",
}

def pick_mbox() -> Path:
    # Prefer a specifically-named file if present
    preferred = HERE / "All mail.mbox"
    if preferred.exists():
        return preferred

    # Otherwise pick the largest *.mbox in this folder
    candidates = list(HERE.glob("*.mbox"))
    if not candidates:
        print("✖ No .mbox file found in:", HERE)
        print("  Put your Gmail Takeout .mbox file in this folder and rerun.")
        sys.exit(2)

    candidates.sort(key=lambda p: p.stat().st_size, reverse=True)
    return candidates[0]

def assert_mbox_ok(mbox: Path) -> None:
    if not mbox.exists():
        print("✖ MBOX not found:", mbox)
        sys.exit(2)

    size = mbox.stat().st_size
    if size == 0:
        print("✖ Your MBOX file is EMPTY (0 bytes):", mbox)
        print("  This is why inbox_metadata.csv is blank.")
        print("  Copy your real Gmail Takeout .mbox file here (it should be large).")
        sys.exit(2)

    if size < 1024 * 1024:  # < 1MB is almost certainly wrong for real mail
        print("⚠ Warning: MBOX is very small:", mbox, f"({size} bytes)")
        print("  If you expected lots of mail, you probably grabbed the wrong file.")

def run(step: str, cmd: list[str]) -> None:
    print(f"\n→ {step}")
    print("  " + " ".join(cmd))
    r = subprocess.run(cmd, cwd=HERE)
    if r.returncode != 0:
        print(f"\n✖ Pipeline stopped at step: {step}")
        sys.exit(r.returncode)

def main() -> None:
    mbox = pick_mbox()
    assert_mbox_ok(mbox)
    print(f"✓ Using MBOX: {mbox.name} ({mbox.stat().st_size:,} bytes)")

    run("extract_headers", [
        PY, "extract_headers.py",
        "--mbox", str(mbox),
        "--out", str(FILES["inbox"]),
    ])

    run("extract_relationships", [
        PY, "extract_relationships.py",
        "--in", str(FILES["inbox"]),
        "--out", str(FILES["raw"]),
    ])

    run("filter_relationships", [
        PY, "filter_relationships.py",
        "--in", str(FILES["raw"]),
        "--out", str(FILES["filtered"]),
    ])

    run("clean_relationships", [
        PY, "clean_relationships.py",
        "--in", str(FILES["filtered"]),
        "--out", str(FILES["clean"]),
    ])

    run("analyze_relationships (filtered)", [
        PY, "analyze_relationships.py",
        "--in", str(FILES["filtered"]),
    ])

    run("reanalyze_clean_relationships", [
        PY, "reanalyze_clean_relationships.py",
        "--in", str(FILES["clean"]),
    ])

    run("build_core_timeline", [
        PY, "build_core_timeline.py",
        "--in", str(FILES["clean"]),
        "--out", str(FILES["core"]),
    ])

    run("preview_core_timeline", [
        PY, "preview_core_timeline.py",
        "--in", str(FILES["core"]),
    ])

    run("plot_core_timeline", [
        PY, "plot_core_timeline.py",
        "--in", str(FILES["core"]),
    ])

    print("\n✅ Gmail pipeline complete.")
    print("Output folder:", OUT)

if __name__ == "__main__":
    main()
